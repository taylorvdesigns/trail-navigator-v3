<?php
/**
 * POI Database Class
 * 
 * Handles all database operations for POIs
 */

if (!defined('ABSPATH')) {
    exit;
}

class TNPOI_POI_DB {
    
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'tnpoi_pois';
    }
    
    /**
     * Get table name
     */
    public function get_table_name() {
        return $this->table_name;
    }
    
    /**
     * Create database table
     */
    public static function create_table() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'tnpoi_pois';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE {$table_name} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            place_id varchar(255) NOT NULL,
            name varchar(255) NOT NULL,
            address text,
            latitude decimal(10,8) NOT NULL,
            longitude decimal(11,8) NOT NULL,
            types text,
            rating decimal(2,1) DEFAULT 0,
            user_ratings_total int(11) DEFAULT 0,
            price_level tinyint(1) DEFAULT 0,
            search_term varchar(255),
            search_location varchar(255),
            search_radius int(11),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY place_id (place_id),
            KEY latitude (latitude),
            KEY longitude (longitude),
            KEY search_term (search_term),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Insert or update POI
     */
    public function insert_or_update_poi($poi_data) {
        global $wpdb;
        $table = $this->get_table_name();
        // Try to insert, if duplicate, update
        $result = $wpdb->replace($table, $poi_data);
        if ($result === false || $result === 0) {
            return false;
        }
        return true;
    }
    
    /**
     * Insert new POI
     */
    public function insert_poi($data) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'place_id' => $data['place_id'],
                'name' => $data['name'],
                'address' => $data['address'],
                'latitude' => $data['latitude'],
                'longitude' => $data['longitude'],
                'types' => $data['types'],
                'rating' => $data['rating'],
                'user_ratings_total' => $data['user_ratings_total'],
                'price_level' => $data['price_level'],
                'search_term' => $data['search_term'],
                'search_location' => $data['search_location'],
                'search_radius' => $data['search_radius'],
                'created_at' => $data['created_at'],
                'updated_at' => $data['updated_at']
            ),
            array(
                '%s', '%s', '%s', '%f', '%f', '%s', '%f', '%d', '%d', '%s', '%s', '%d', '%s', '%s'
            )
        );
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Update existing POI
     */
    public function update_poi($id, $data) {
        global $wpdb;
        
        $update_data = array();
        $format = array();
        
        if (isset($data['name'])) {
            $update_data['name'] = $data['name'];
            $format[] = '%s';
        }
        if (isset($data['address'])) {
            $update_data['address'] = $data['address'];
            $format[] = '%s';
        }
        if (isset($data['latitude'])) {
            $update_data['latitude'] = $data['latitude'];
            $format[] = '%f';
        }
        if (isset($data['longitude'])) {
            $update_data['longitude'] = $data['longitude'];
            $format[] = '%f';
        }
        if (isset($data['types'])) {
            $update_data['types'] = $data['types'];
            $format[] = '%s';
        }
        if (isset($data['rating'])) {
            $update_data['rating'] = $data['rating'];
            $format[] = '%f';
        }
        if (isset($data['user_ratings_total'])) {
            $update_data['user_ratings_total'] = $data['user_ratings_total'];
            $format[] = '%d';
        }
        if (isset($data['price_level'])) {
            $update_data['price_level'] = $data['price_level'];
            $format[] = '%d';
        }
        if (isset($data['updated_at'])) {
            $update_data['updated_at'] = $data['updated_at'];
            $format[] = '%s';
        }
        
        if (empty($update_data)) {
            return false;
        }
        
        $result = $wpdb->update(
            $this->table_name,
            $update_data,
            array('id' => $id),
            $format,
            array('%d')
        );
        
        return $result !== false;
    }
    
    /**
     * Delete POI
     */
    public function delete_poi($id) {
        global $wpdb;
        
        return $wpdb->delete(
            $this->table_name,
            array('id' => $id),
            array('%d')
        );
    }
    
    /**
     * Get single POI
     */
    public function get_poi($id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $id
        ));
    }
    
    /**
     * Get all POIs
     */
    public function get_all_pois() {
        global $wpdb;
        
        return $wpdb->get_results(
            "SELECT * FROM {$this->table_name} ORDER BY created_at DESC"
        );
    }
    
    /**
     * Get recent POIs
     */
    public function get_recent_pois($limit = 10) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} ORDER BY created_at DESC LIMIT %d",
            $limit
        ));
    }
    
    /**
     * Get POIs with pagination and filtering
     */
    public function get_pois_paginated($page = 1, $per_page = 20, $search = '', $filter_type = '', $filter_search_term = '') {
        global $wpdb;
        
        $offset = ($page - 1) * $per_page;
        $where_conditions = array();
        $where_values = array();
        
        // Search filter
        if (!empty($search)) {
            $where_conditions[] = "(name LIKE %s OR address LIKE %s)";
            $where_values[] = '%' . $wpdb->esc_like($search) . '%';
            $where_values[] = '%' . $wpdb->esc_like($search) . '%';
        }
        
        // Type filter
        if (!empty($filter_type)) {
            $where_conditions[] = "types LIKE %s";
            $where_values[] = '%' . $wpdb->esc_like($filter_type) . '%';
        }
        
        // Search term filter
        if (!empty($filter_search_term)) {
            $where_conditions[] = "search_term = %s";
            $where_values[] = $filter_search_term;
        }
        
        $where_clause = '';
        if (!empty($where_conditions)) {
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
        }
        
        $sql = "SELECT * FROM {$this->table_name} {$where_clause} ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $where_values[] = $per_page;
        $where_values[] = $offset;
        
        return $wpdb->get_results($wpdb->prepare($sql, $where_values));
    }
    
    /**
     * Get POI count with filtering
     */
    public function get_pois_count($search = '', $filter_type = '', $filter_search_term = '') {
        global $wpdb;
        
        $where_conditions = array();
        $where_values = array();
        
        // Search filter
        if (!empty($search)) {
            $where_conditions[] = "(name LIKE %s OR address LIKE %s)";
            $where_values[] = '%' . $wpdb->esc_like($search) . '%';
            $where_values[] = '%' . $wpdb->esc_like($search) . '%';
        }
        
        // Type filter
        if (!empty($filter_type)) {
            $where_conditions[] = "types LIKE %s";
            $where_values[] = '%' . $wpdb->esc_like($filter_type) . '%';
        }
        
        // Search term filter
        if (!empty($filter_search_term)) {
            $where_conditions[] = "search_term = %s";
            $where_values[] = $filter_search_term;
        }
        
        $where_clause = '';
        if (!empty($where_conditions)) {
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
        }
        
        $sql = "SELECT COUNT(*) FROM {$this->table_name} {$where_clause}";
        
        if (!empty($where_values)) {
            return $wpdb->get_var($wpdb->prepare($sql, $where_values));
        } else {
            return $wpdb->get_var($sql);
        }
    }
    
    /**
     * Get POIs by search term
     */
    public function get_pois_by_search_term($search_term) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE search_term = %s ORDER BY created_at DESC",
            $search_term
        ));
    }
    
    /**
     * Get POIs within radius
     */
    public function get_pois_in_radius($lat, $lng, $radius_km) {
        global $wpdb;
        
        $radius_meters = $radius_km * 1000;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT *, 
             (6371000 * acos(cos(radians(%f)) * cos(radians(latitude)) * cos(radians(longitude) - radians(%f)) + sin(radians(%f)) * sin(radians(latitude)))) AS distance 
             FROM {$this->table_name} 
             HAVING distance <= %f 
             ORDER BY distance",
            $lat, $lng, $lat, $radius_meters
        ));
    }
    
    /**
     * Get unique search terms
     */
    public function get_unique_search_terms() {
        global $wpdb;
        
        return $wpdb->get_col(
            "SELECT DISTINCT search_term FROM {$this->table_name} WHERE search_term IS NOT NULL AND search_term != '' ORDER BY search_term"
        );
    }
    
    /**
     * Get statistics
     */
    public function get_stats() {
        global $wpdb;
        
        return array(
            'total_pois' => $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}"),
            'recent_pois' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table_name} WHERE created_at >= %s",
                date('Y-m-d H:i:s', strtotime('-24 hours'))
            )),
            'search_terms' => $wpdb->get_var("SELECT COUNT(DISTINCT search_term) FROM {$this->table_name}"),
            'avg_rating' => $wpdb->get_var("SELECT AVG(rating) FROM {$this->table_name} WHERE rating > 0"),
            'top_types' => $wpdb->get_results(
                "SELECT types, COUNT(*) as count FROM {$this->table_name} GROUP BY types ORDER BY count DESC LIMIT 5"
            )
        );
    }
    
    /**
     * Clean old POIs
     */
    public function clean_old_pois($days = 30) {
        global $wpdb;
        
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        return $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table_name} WHERE created_at < %s",
            $cutoff_date
        ));
    }
    
    /**
     * Export POIs for CSV
     */
    public function export_pois_for_csv($filters = array()) {
        global $wpdb;
        
        $where_conditions = array();
        $where_values = array();
        
        if (!empty($filters['search_term'])) {
            $where_conditions[] = "search_term = %s";
            $where_values[] = $filters['search_term'];
        }
        
        if (!empty($filters['type'])) {
            $where_conditions[] = "types LIKE %s";
            $where_values[] = '%' . $wpdb->esc_like($filters['type']) . '%';
        }
        
        $where_clause = '';
        if (!empty($where_conditions)) {
            $where_clause = 'WHERE ' . implode(' AND ', $where_conditions);
        }
        
        $sql = "SELECT * FROM {$this->table_name} {$where_clause} ORDER BY created_at DESC";
        
        if (!empty($where_values)) {
            return $wpdb->get_results($wpdb->prepare($sql, $where_values));
        } else {
            return $wpdb->get_results($sql);
        }
    }
} 