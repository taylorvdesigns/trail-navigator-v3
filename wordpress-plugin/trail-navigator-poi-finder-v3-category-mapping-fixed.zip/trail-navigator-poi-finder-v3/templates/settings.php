<?php
/**
 * Settings Template
 * 
 * Displays the plugin settings page with category mapping interface
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap tnpoi-admin">
    <h1>Trail Navigator POI Finder - Settings</h1>
    
    <div class="tnpoi-card">
        <form method="post" action="options.php">
            <?php
            settings_fields('tnpoi_settings_group');
            do_settings_sections('tnpoi_settings');
            submit_button('Save Settings');
            ?>
        </form>
    </div>
    
    <div class="tnpoi-card">
        <h2>Trail Selection</h2>
        <p>Select which trails to sync POIs for:</p>
        
        <?php
        $settings = new TNPOI_Settings();
        $available_trails = $settings->get_available_trails();
        $selected_trails = get_option('tnpoi_selected_trails', array());
        ?>
        
        <div class="tnpoi-form-group">
            <label>Available Trails:</label>
            <div class="tnpoi-checkbox-group">
                <?php foreach ($available_trails as $trail_id => $trail_name): ?>
                    <label class="tnpoi-checkbox-item">
                        <input type="checkbox" 
                               name="tnpoi_selected_trails[]" 
                               value="<?php echo esc_attr($trail_id); ?>"
                               <?php checked(in_array($trail_id, $selected_trails)); ?>>
                        <?php echo esc_html($trail_name); ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>
        
        <button type="button" class="button button-primary" onclick="saveTrailSelection()">
            Save Trail Selection
        </button>
    </div>
    
    <div class="tnpoi-card">
        <h2>Category Mapping</h2>
        <p>Map Google Places types to GeoDirectory categories for automatic assignment during sync operations.</p>
        
        <?php $settings->render_category_mapping_field(); ?>
    </div>
</div>

<script>
function saveTrailSelection() {
    const checkboxes = document.querySelectorAll('input[name="tnpoi_selected_trails[]"]:checked');
    const selectedTrails = Array.from(checkboxes).map(cb => cb.value);
    
    jQuery.post(ajaxurl, {
        action: 'tnpoi_save_trail_selection',
        selected_trails: selectedTrails,
        nonce: tnpoi_ajax.nonce
    }, function(response) {
        if (response.success) {
            alert('Trail selection saved successfully!');
        } else {
            alert('Failed to save trail selection: ' + response.data);
        }
    });
}
</script>

<style>
.tnpoi-checkbox-group {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 10px;
    margin-top: 10px;
}

.tnpoi-checkbox-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.2s ease;
}

.tnpoi-checkbox-item:hover {
    background-color: #f8f9fa;
}

.tnpoi-checkbox-item input[type="checkbox"] {
    margin: 0;
}
</style> 