/**
 * Trail Navigator POI Finder - Map JavaScript
 * 
 * Handles map functionality and trail visualization
 */

(function($) {
    'use strict';
    
    // Global variables
    var map;
    var trailLine = null;
    var markers = [];
    var searchAreaCircles = [];
    var syncPreviewData = null;
    
    // Initialize when document is ready
    $(document).ready(function() {
        if ($('#poi-map').length) {
            initializeMap();
            setupEventListeners();
        }
    });
    
    /**
     * Initialize the map
     */
    function initializeMap() {
        // Get center from PHP data or use default
        var centerLat = 39.8283;
        var centerLng = -98.5795;
        var zoom = 4;
        
        if (window.tnpoiMapData && window.tnpoiMapData.selectedTrail) {
            // Use trail center if available
            var trail = window.tnpoiMapData.selectedTrail;
            if (trail.trackPoints && trail.trackPoints.length > 0) {
                var firstPoint = trail.trackPoints[0];
                centerLat = parseFloat(firstPoint.lat);
                centerLng = parseFloat(firstPoint.lng);
                zoom = 10;
            }
        }
        
        // Create map centered on calculated location
        map = L.map('poi-map').setView([centerLat, centerLng], zoom);
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Add trail line if trail data is available
        if (window.tnpoiMapData && window.tnpoiMapData.selectedTrail && window.tnpoiMapData.selectedTrail.trackPoints) {
            addTrailLine(window.tnpoiMapData.selectedTrail.trackPoints);
        }
    }
    
    /**
     * Add trail line to map
     */
    function addTrailLine(trackPoints) {
        if (!trackPoints || trackPoints.length < 2) return;
        
        var trailCoords = trackPoints.map(function(point) {
            return [parseFloat(point.lat), parseFloat(point.lng)];
        });
        
        trailLine = L.polyline(trailCoords, {
            color: '#2271b1',
            weight: 4,
            opacity: 0.8
        }).addTo(map);
        
        // Fit map to trail bounds
        map.fitBounds(trailLine.getBounds().pad(0.1));
    }
    
    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Mode switching
        $('input[name="map-mode"]').on('change', function() {
            var mode = $(this).val();
            switchMapMode(mode);
        });
        
        // Trail view controls
        $('#fit-trail-bounds').on('click', fitTrailBounds);
        $('#load-pois').on('click', loadPOIs);
        
        // Sync preview controls
        $('#update-sync-preview').on('click', updateSyncPreview);
        $('#start-sync-from-preview').on('click', startSyncFromPreview);
    }
    
    /**
     * Switch between trail view and sync preview modes
     */
    function switchMapMode(mode) {
        if (mode === 'trail-view') {
            $('#trail-view-controls').show();
            $('#sync-preview-controls').hide();
            $('#poi-stats').hide();
            $('#sync-preview-stats').hide();
            
            // Clear sync preview elements
            clearSearchAreas();
        } else if (mode === 'sync-preview') {
            $('#trail-view-controls').hide();
            $('#sync-preview-controls').show();
            $('#poi-stats').hide();
            $('#sync-preview-stats').show();
            
            // Load sync preview
            loadSyncPreview();
        }
    }
    
    /**
     * Fit map to trail bounds
     */
    function fitTrailBounds() {
        if (trailLine) {
            map.fitBounds(trailLine.getBounds().pad(0.1));
        }
    }
    
    /**
     * Load POIs for the selected trail
     */
    function loadPOIs() {
        if (!window.tnpoiMapData || !window.tnpoiMapData.selectedTrail) {
            alert('Please select a trail first');
            return;
        }
        
        var trailId = window.tnpoiMapData.selectedTrail.routeId;
        
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_pois',
                nonce: tnpoi_map_ajax.nonce,
                filters: {
                    trail: trailId
                }
            },
            success: function(response) {
                if (response.success) {
                    addPOIMarkers(response.data);
                    $('#poi-stats').show();
                    $('#poi-count-display').text(response.data.length);
                } else {
                    console.error('Failed to load POIs:', response.data);
                    $('#poi-stats').show();
                    $('#poi-count-display').text('0');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                $('#poi-stats').show();
                $('#poi-count-display').text('0');
            }
        });
    }
    
    /**
     * Add POI markers to map
     */
    function addPOIMarkers(pois) {
        // Clear existing markers
        clearMarkers();
        
        if (!pois || pois.length === 0) {
            console.log('No POIs to display');
            return;
        }
        
        pois.forEach(function(poi) {
            var markerIcon = L.divIcon({
                className: 'poi-marker',
                html: '<div style="background-color: #e74c3c; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [12, 12],
                iconAnchor: [6, 6]
            });
            
            var marker = L.marker([parseFloat(poi.latitude), parseFloat(poi.longitude)], {icon: markerIcon})
                .addTo(map)
                .bindPopup('<div class="poi-popup"><h3>' + poi.name + '</h3><p>' + (poi.address || 'No address') + '</p></div>');
            
            markers.push(marker);
        });
    }
    
    /**
     * Clear all markers from map
     */
    function clearMarkers() {
        markers.forEach(function(marker) {
            map.removeLayer(marker);
        });
        markers = [];
    }
    
    /**
     * Load sync preview data
     */
    function loadSyncPreview() {
        if (!window.tnpoiMapData || !window.tnpoiMapData.selectedTrail) {
            alert('Please select a trail first');
            return;
        }
        
        var trailId = window.tnpoiMapData.selectedTrail.routeId;
        var searchRadius = $('#search-radius').val();
        
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_sync_preview',
                nonce: tnpoi_map_ajax.nonce,
                trail_id: trailId,
                search_radius: searchRadius
            },
            success: function(response) {
                if (response.success) {
                    syncPreviewData = response.data;
                    displaySyncPreview(syncPreviewData);
                } else {
                    console.error('Failed to load sync preview:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    }
    
    /**
     * Display sync preview on map
     */
    function displaySyncPreview(data) {
        clearSearchAreas();
        
        // Add sampled points as markers
        data.sampled_points.forEach(function(point, index) {
            var markerIcon = L.divIcon({
                className: 'sampled-point-marker',
                html: '<div style="background-color: #0073aa; width: 8px; height: 8px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [8, 8],
                iconAnchor: [4, 4]
            });
            
            var marker = L.marker([point.lat, point.lng], {icon: markerIcon})
                .addTo(map)
                .bindPopup('Sampled Point ' + (index + 1) + '<br>Search Radius: ' + point.search_radius + 'm');
            
            // Add search radius circle
            var circle = L.circle([point.lat, point.lng], {
                color: '#0073aa',
                fillColor: '#0073aa',
                fillOpacity: 0.1,
                radius: point.search_radius
            }).addTo(map);
            
            searchAreaCircles.push(circle);
        });
        
        // Update stats
        $('#sampled-points-display').text(data.total_points);
        $('#api-calls-display').text(data.estimated_api_calls);
    }
    
    /**
     * Clear search area circles
     */
    function clearSearchAreas() {
        searchAreaCircles.forEach(function(circle) {
            map.removeLayer(circle);
        });
        searchAreaCircles = [];
    }
    
    /**
     * Update sync preview with new parameters
     */
    function updateSyncPreview() {
        loadSyncPreview();
    }
    
    /**
     * Start sync from preview
     */
    function startSyncFromPreview() {
        if (!syncPreviewData) {
            alert('Please load sync preview first');
            return;
        }
        
        if (confirm('Start POI sync with current preview settings? This will make approximately ' + syncPreviewData.estimated_api_calls + ' API calls.')) {
            // Redirect to sync page with parameters
            var params = new URLSearchParams({
                trail_id: syncPreviewData.trail_id,
                search_radius: syncPreviewData.search_radius
            });
            
            window.location.href = 'admin.php?page=tnpoi-sync&' + params.toString();
        }
    }
    
})(jQuery);
