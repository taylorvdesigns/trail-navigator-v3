<?php
/**
 * Map Preview Template
 * 
 * Interactive map preview using Leaflet.js with trail visualization
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get available trails and selected trail
$trail_config = get_option('trail_navigator_config', array());
$available_trails = isset($trail_config['trails']) ? $trail_config['trails'] : array();
$selected_trail_id = $_GET['trail_id'] ?? '';
$selected_trail = null;

if ($selected_trail_id) {
    foreach ($available_trails as $trail) {
        if ($trail['routeId'] === $selected_trail_id) {
            $selected_trail = $trail;
            break;
        }
    }
}
?>

<div class="wrap tnpoi-map-preview">
    <h1 class="wp-heading-inline">Map Preview</h1>
    <a href="<?php echo admin_url('admin.php?page=tnpoi-poi-manager'); ?>" class="page-title-action">Manage POIs</a>
    
    <!-- Trail Selection -->
    <div class="tnpoi-trail-selection-panel">
        <h3>Select Trail for Preview</h3>
        <form method="get" action="" class="tnpoi-trail-form">
            <input type="hidden" name="page" value="tnpoi-map-preview">
            <select name="trail_id" id="trail-selector" onchange="this.form.submit()">
                <option value="">-- Select a trail --</option>
                <?php foreach ($available_trails as $trail): ?>
                    <option value="<?php echo esc_attr($trail['routeId']); ?>" 
                            <?php selected($selected_trail_id, $trail['routeId']); ?>>
                        <?php echo esc_html($trail['name']); ?> 
                        (<?php echo count($trail['trackPoints'] ?? array()); ?> points)
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        
        <?php if ($selected_trail): ?>
            <div class="tnpoi-trail-info">
                <h4><?php echo esc_html($selected_trail['name']); ?></h4>
                <p><strong>Route ID:</strong> <?php echo esc_html($selected_trail['routeId']); ?></p>
                <p><strong>Track Points:</strong> <?php echo count($selected_trail['trackPoints'] ?? array()); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if ($selected_trail): ?>
    <div class="tnpoi-map-controls">
        <!-- Mode Toggle -->
        <div class="tnpoi-mode-toggle">
            <label class="tnpoi-mode-option">
                <input type="radio" name="map-mode" value="trail-view" checked>
                <span>Trail View</span>
            </label>
            <label class="tnpoi-mode-option">
                <input type="radio" name="map-mode" value="sync-preview">
                <span>Sync Preview</span>
            </label>
        </div>
        
        <!-- Trail View Controls -->
        <div class="tnpoi-map-filters" id="trail-view-controls">
            <div class="tnpoi-filter-actions">
                <button type="button" id="fit-trail-bounds" class="button button-secondary">Fit Trail</button>
                <button type="button" id="load-pois" class="button">Load POIs</button>
            </div>
        </div>
        
        <!-- Sync Preview Controls -->
        <div class="tnpoi-map-filters" id="sync-preview-controls" style="display: none;">
            <div class="tnpoi-filter-group">
                <label for="search-radius">Search Radius (meters):</label>
                <input type="number" id="search-radius" value="500" min="50" max="5000" step="50" class="small-text">
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="coordinate-interval">Coordinate Interval (meters):</label>
                <select id="coordinate-interval">
                    <option value="100">100m (High Density)</option>
                    <option value="200">200m (Medium Density)</option>
                    <option value="300">300m (Low Density)</option>
                    <option value="500">500m (Very Low Density)</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-actions">
                <button type="button" id="update-sync-preview" class="button">Update Preview</button>
                <button type="button" id="start-sync-from-preview" class="button button-primary">Start Sync</button>
            </div>
        </div>
        
        <div class="tnpoi-map-stats">
            <span class="tnpoi-stat">Trail Points: <span id="trail-points-display"><?php echo count($selected_trail['trackPoints'] ?? array()); ?></span></span>
            <span class="tnpoi-stat" id="poi-stats" style="display: none;">POIs: <span id="poi-count-display">0</span></span>
            <span class="tnpoi-stat" id="sync-preview-stats" style="display: none;">
                Sampled Points: <span id="sampled-points-display">-</span> | 
                API Calls: <span id="api-calls-display">-</span>
            </span>
        </div>
    </div>
    
    <div class="tnpoi-map-container">
        <div id="poi-map" style="height: 600px; width: 100%;"></div>
    </div>
    <?php else: ?>
    <div class="tnpoi-no-trail-selected">
        <p>Please select a trail above to view the map preview.</p>
    </div>
    <?php endif; ?>
</div>

<!-- Load the map JavaScript -->
<script>
// Pass PHP data to JavaScript
window.tnpoiMapData = {
    selectedTrail: <?php echo json_encode($selected_trail); ?>,
    availableTrails: <?php echo json_encode($available_trails); ?>
};
</script>

<style>
.tnpoi-map-preview {
    margin: 20px 0;
}

.tnpoi-map-controls {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-mode-toggle {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
}

.tnpoi-mode-option {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border: 2px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tnpoi-mode-option:hover {
    border-color: #0073aa;
    background-color: #f0f8ff;
}

.tnpoi-mode-option input[type="radio"] {
    margin: 0;
}

.tnpoi-mode-option input[type="radio"]:checked + span {
    font-weight: 600;
    color: #0073aa;
}

.tnpoi-mode-option input[type="radio"]:checked ~ .tnpoi-mode-option {
    border-color: #0073aa;
    background-color: #e6f3ff;
}

.tnpoi-map-filters {
    display: flex;
    gap: 20px;
    align-items: end;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.tnpoi-filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-filter-group label {
    font-weight: 500;
    color: #1d2327;
}

.tnpoi-filter-actions {
    display: flex;
    gap: 10px;
    align-items: end;
}

.tnpoi-map-stats {
    display: flex;
    gap: 20px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.tnpoi-stat {
    font-weight: 500;
    color: #666;
}

.tnpoi-stat span {
    color: #2271b1;
    font-weight: 600;
}

.tnpoi-map-container {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.tnpoi-map-sidebar {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-poi-list h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #1d2327;
}

#poi-list-container {
    max-height: 400px;
    overflow-y: auto;
}

.tnpoi-poi-list-item {
    padding: 10px;
    border: 1px solid #f0f0f0;
    border-radius: 6px;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tnpoi-poi-list-item:hover {
    background: #f9f9f9;
    border-color: #2271b1;
}

.tnpoi-poi-list-item.selected {
    background: #e7f3ff;
    border-color: #2271b1;
}

.tnpoi-poi-list-item h4 {
    margin: 0 0 5px 0;
    color: #2271b1;
    font-size: 1em;
}

.tnpoi-poi-list-item p {
    margin: 0;
    color: #666;
    font-size: 0.9em;
}

.tnpoi-poi-meta {
    display: flex;
    gap: 10px;
    margin-top: 5px;
    font-size: 0.8em;
    color: #888;
}

.tnpoi-loading {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 20px;
}

/* Leaflet customizations */
.leaflet-popup-content {
    margin: 10px;
    min-width: 200px;
}

.leaflet-popup-content h3 {
    margin: 0 0 10px 0;
    color: #2271b1;
}

.leaflet-popup-content p {
    margin: 5px 0;
    color: #666;
}

.leaflet-popup-content .poi-rating {
    color: #f39c12;
    font-weight: 500;
}

.leaflet-popup-content .poi-type {
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    color: #666;
    display: inline-block;
    margin-top: 5px;
}

/* Modal Styles */
.tnpoi-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tnpoi-modal-content {
    background: #fff;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.tnpoi-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.tnpoi-modal-header h2 {
    margin: 0;
}

.tnpoi-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}

.tnpoi-modal-close:hover {
    color: #000;
}

.tnpoi-modal-body {
    padding: 20px;
}

.tnpoi-modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

@media (max-width: 768px) {
    .tnpoi-map-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tnpoi-filter-actions {
        justify-content: center;
    }
    
    .tnpoi-map-stats {
        flex-direction: column;
        gap: 10px;
    }
    
    #poi-map {
        height: 400px;
    }
}
</style> 