<?php
/**
 * POI Sync Class
 * 
 * Handles Google Places API integration and POI synchronization
 * with coordinate thinning and progress tracking
 */

if (!defined('ABSPATH')) {
    exit;
}

class TNPOI_Sync {
    
    private $api_key;
    private $db;
    public $interval = 200; // Default sampling interval in meters
    
    public function __construct() {
        $this->db = new TNPOI_POI_DB();
        $this->api_key = get_option('tnpoi_google_places_api_key', '');
        
        add_action('wp_ajax_tnpoi_sync_pois', array($this, 'ajax_sync_pois'));
        add_action('wp_ajax_tnpoi_get_sync_progress', array($this, 'ajax_get_sync_progress'));
    }
    
    /**
     * AJAX handler for POI synchronization
     */
    public function ajax_sync_pois() {
        check_ajax_referer('tnpoi_sync_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $action = sanitize_text_field($_POST['action_type'] ?? '');
        
        switch ($action) {
            case 'start':
                $this->start_sync();
                break;
            case 'stop':
                $this->stop_sync();
                break;
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    /**
     * AJAX handler for sync progress
     */
    public function ajax_get_sync_progress() {
        check_ajax_referer('tnpoi_sync_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $progress = get_transient('tnpoi_sync_progress');
        if (!$progress) {
            $progress = array(
                'status' => 'idle',
                'current' => 0,
                'total' => 0,
                'message' => 'No sync in progress'
            );
        }
        
        wp_send_json_success($progress);
    }
    
    /**
     * Start POI synchronization
     */
    private function start_sync() {
        if (empty($this->api_key)) {
            wp_send_json_error('Google Places API key not configured');
        }
        
        $search_terms = get_option('tnpoi_search_terms', array());
        if (empty($search_terms)) {
            wp_send_json_error('No search terms configured');
        }
        
        // Initialize progress
        $total_terms = count($search_terms);
        $progress = array(
            'status' => 'running',
            'current' => 0,
            'total' => $total_terms,
            'message' => 'Starting sync...'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Start background process
        wp_schedule_single_event(time(), 'tnpoi_process_sync', array($search_terms, 0));
        
        wp_send_json_success(array(
            'message' => 'Sync started',
            'total_terms' => $total_terms
        ));
    }
    
    /**
     * Stop POI synchronization
     */
    private function stop_sync() {
        $progress = array(
            'status' => 'stopped',
            'current' => 0,
            'total' => 0,
            'message' => 'Sync stopped by user'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        wp_clear_scheduled_hook('tnpoi_process_sync');
        
        wp_send_json_success('Sync stopped');
    }
    
    /**
     * Process sync in background
     */
    public function process_sync($search_terms, $current_index = 0) {
        if ($current_index >= count($search_terms)) {
            $this->complete_sync();
            return;
        }
        
        $term = $search_terms[$current_index];
        $this->sync_search_term($term);
        
        // Update progress
        $progress = array(
            'status' => 'running',
            'current' => $current_index + 1,
            'total' => count($search_terms),
            'message' => "Processed: {$term['name']}"
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Schedule next batch
        wp_schedule_single_event(time() + 2, 'tnpoi_process_sync', array($search_terms, $current_index + 1));
    }
    
    /**
     * Sync a single search term
     */
    private function sync_search_term($term) {
        $location = $term['location'];
        $radius = intval($term['radius']);
        $types = $term['types'];
        
        // Search for places
        $places = $this->search_places($location, $radius, $types);
        
        if (empty($places)) {
            return;
        }
        
        // Apply coordinate thinning
        $thinned_places = $this->thin_coordinates($places, $term['min_distance'] ?? 100);
        
        // Save POIs
        foreach ($thinned_places as $place) {
            $this->save_poi($place, $term);
        }
    }
    
    /**
     * Search Google Places API
     */
    private function search_places($location, $radius, $types) {
        $places = array();
        $next_page_token = null;
        
        do {
            $url = add_query_arg(array(
                'location' => $location,
                'radius' => $radius,
                'type' => $types,
                'key' => $this->api_key
            ), 'https://maps.googleapis.com/maps/api/place/nearbysearch/json');
            
            if ($next_page_token) {
                $url = add_query_arg('pagetoken', $next_page_token, $url);
            }
            
            $response = wp_remote_get($url);
            
            if (is_wp_error($response)) {
                error_log('Google Places API error: ' . $response->get_error_message());
                break;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (!$data || $data['status'] !== 'OK') {
                error_log('Google Places API error: ' . ($data['status'] ?? 'Unknown error'));
                break;
            }
            
            $places = array_merge($places, $data['results']);
            $next_page_token = $data['next_page_token'] ?? null;
            
            // Respect API rate limits
            if ($next_page_token) {
                sleep(2);
            }
            
        } while ($next_page_token);
        
        return $places;
    }
    
    /**
     * Apply coordinate thinning to reduce density
     */
    private function thin_coordinates($places, $min_distance) {
        if (empty($places)) {
            return array();
        }
        
        $thinned = array();
        $thinned[] = $places[0]; // Keep first place
        
        foreach ($places as $place) {
            $keep = true;
            
            foreach ($thinned as $kept_place) {
                $distance = $this->calculate_distance(
                    $place['geometry']['location']['lat'],
                    $place['geometry']['location']['lng'],
                    $kept_place['geometry']['location']['lat'],
                    $kept_place['geometry']['location']['lng']
                );
                
                if ($distance < $min_distance) {
                    $keep = false;
                    break;
                }
            }
            
            if ($keep) {
                $thinned[] = $place;
            }
        }
        
        return $thinned;
    }
    
    /**
     * Calculate distance between two coordinates (Haversine formula)
     */
    private function calculate_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // meters
        
        $lat1_rad = deg2rad($lat1);
        $lng1_rad = deg2rad($lng1);
        $lat2_rad = deg2rad($lat2);
        $lng2_rad = deg2rad($lng2);
        
        $dlat = $lat2_rad - $lat1_rad;
        $dlng = $lng2_rad - $lng1_rad;
        
        $a = sin($dlat / 2) * sin($dlat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($dlng / 2) * sin($dlng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Haversine distance calculation (alias for calculate_distance)
     */
    private function haversine_distance($lat1, $lng1, $lat2, $lng2) {
        return $this->calculate_distance($lat1, $lng1, $lat2, $lng2);
    }
    
    /**
     * Save POI to database
     */
    private function save_poi($place, $term) {
        $poi_data = array(
            'place_id' => $place['place_id'],
            'name' => $place['name'],
            'address' => $place['vicinity'] ?? '',
            'latitude' => $place['geometry']['location']['lat'],
            'longitude' => $place['geometry']['location']['lng'],
            'types' => implode(',', $place['types']),
            'rating' => $place['rating'] ?? 0,
            'user_ratings_total' => $place['user_ratings_total'] ?? 0,
            'price_level' => $place['price_level'] ?? 0,
            'search_term' => $term['name'],
            'search_location' => $term['location'],
            'search_radius' => $term['radius'],
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        $this->db->insert_or_update_poi($poi_data);
    }
    
    /**
     * Complete sync process
     */
    private function complete_sync() {
        $progress = array(
            'status' => 'completed',
            'current' => 0,
            'total' => 0,
            'message' => 'Sync completed successfully'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Clear scheduled events
        wp_clear_scheduled_hook('tnpoi_process_sync');
    }
    
    /**
     * Get sync statistics
     */
    public function get_sync_stats() {
        global $wpdb;
        
        $table_name = $this->db->get_table_name();
        
        $stats = array(
            'total_pois' => $wpdb->get_var("SELECT COUNT(*) FROM $table_name"),
            'recent_pois' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE created_at >= %s",
                date('Y-m-d H:i:s', strtotime('-24 hours'))
            )),
            'search_terms' => $wpdb->get_var("SELECT COUNT(DISTINCT search_term) FROM $table_name"),
            'last_sync' => get_option('tnpoi_last_sync', 'Never')
        );
        
        return $stats;
    }
    
    /**
     * Get sampled points for a trail (coordinate thinning)
     */
    public function get_sampled_points($trail_id) {
        error_log('TNPOI Sync: Getting sampled points for trail_id: ' . $trail_id);
        
        $trail_config = get_option('trail_navigator_config', array());
        $trails = isset($trail_config['trails']) ? $trail_config['trails'] : array();
        
        error_log('TNPOI Sync: Found ' . count($trails) . ' trails in config');
        
        $selected_trail = null;
        foreach ($trails as $trail) {
            if ((string)$trail['routeId'] === (string)$trail_id) {
                $selected_trail = $trail;
                error_log('TNPOI Sync: Found matching trail: ' . $trail['name']);
                break;
            }
        }
        
        if (!$selected_trail) {
            error_log('TNPOI Sync: No trail found with routeId: ' . $trail_id);
            return array();
        }
        
        if (empty($selected_trail['trackPoints'])) {
            error_log('TNPOI Sync: No trackPoints found in selected trail');
            error_log('TNPOI Sync: Trail keys: ' . implode(', ', array_keys($selected_trail)));
            return array();
        }
        
        error_log('TNPOI Sync: Found ' . count($selected_trail['trackPoints']) . ' track points');
        error_log('TNPOI Sync: Using interval: ' . $this->interval . 'm');
        
        // Use intelligent sampling based on OSM data if available
        if (isset($this->settings) && $this->settings->get_setting('enable_osm_intelligence', false)) {
            error_log('TNPOI Sync: Using intelligent sampling');
            return $this->get_intelligent_sampled_points($selected_trail['trackPoints']);
        }
        
        // Fallback to uniform sampling
        error_log('TNPOI Sync: Using uniform sampling');
        return $this->get_uniform_sampled_points($selected_trail['trackPoints']);
    }
    
    /**
     * Get uniformly sampled points (original method)
     */
    private function get_uniform_sampled_points($track_points) {
        error_log('TNPOI Sync: Starting uniform sampling with ' . count($track_points) . ' points');
        
        $sampled_points = array();
        $last_point = null;
        
        foreach ($track_points as $index => $pt) {
            if (!$last_point) {
                $sampled_points[] = $pt;
                $last_point = $pt;
                error_log('TNPOI Sync: Added first point at index ' . $index);
            } else {
                $dist = $this->haversine_distance($last_point['lat'], $last_point['lng'], $pt['lat'], $pt['lng']);
                if ($dist >= $this->interval) {
                    $sampled_points[] = $pt;
                    $last_point = $pt;
                    error_log('TNPOI Sync: Added point at index ' . $index . ' (distance: ' . round($dist) . 'm)');
                }
            }
        }
        
        error_log('TNPOI Sync: Uniform sampling complete. Sampled ' . count($sampled_points) . ' points from ' . count($track_points) . ' total points');
        return $sampled_points;
    }
    
    /**
     * Get intelligently sampled points using OSM data
     */
    private function get_intelligent_sampled_points($track_points) {
        $sampled_points = array();
        $last_point = null;
        $current_distance = 0;
        
        foreach ($track_points as $pt) {
            if (!$last_point) {
                $sampled_points[] = $pt;
                $last_point = $pt;
                continue;
            }
            
            $dist = $this->haversine_distance($last_point['lat'], $last_point['lng'], $pt['lat'], $pt['lng']);
            $current_distance += $dist;
            
            // Get adaptive interval based on OSM data
            $adaptive_interval = $this->get_adaptive_interval($pt['lat'], $pt['lng']);
            
            if ($current_distance >= $adaptive_interval) {
                $sampled_points[] = $pt;
                $last_point = $pt;
                $current_distance = 0;
            }
        }
        
        return $sampled_points;
    }
    
    /**
     * Get adaptive sampling interval based on OSM data
     */
    private function get_adaptive_interval($lat, $lng) {
        // Query OSM Overpass API for area characteristics
        $osm_data = $this->query_osm_area_data($lat, $lng);
        
        // Analyze the data to determine density
        $density_score = $this->calculate_area_density($osm_data);
        
        // Return adaptive interval based on density
        if ($density_score > 0.7) {
            return 150; // High density: 150m spacing
        } elseif ($density_score > 0.3) {
            return 300; // Medium density: 300m spacing
        } else {
            return 600; // Low density: 600m spacing
        }
    }
    
    /**
     * Query OSM Overpass API for area data
     */
    private function query_osm_area_data($lat, $lng) {
        $radius = 500; // 500m radius to analyze
        
        // Overpass query to get buildings, roads, and amenities
        $query = "
            [out:json][timeout:25];
            (
                way[\"building\"](around:$radius,$lat,$lng);
                way[\"highway\"](around:$radius,$lat,$lng);
                node[\"amenity\"](around:$radius,$lat,$lng);
                way[\"landuse\"](around:$radius,$lat,$lng);
            );
            out body;
            >;
            out skel qt;
        ";
        
        $url = 'https://overpass-api.de/api/interpreter';
        $response = wp_remote_post($url, array(
            'body' => $query,
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            )
        ));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        return json_decode($body, true);
    }
    
    /**
     * Calculate area density score from OSM data
     */
    private function calculate_area_density($osm_data) {
        if (empty($osm_data['elements'])) {
            return 0.1; // Default to low density if no data
        }
        
        $building_count = 0;
        $road_count = 0;
        $amenity_count = 0;
        $commercial_landuse = 0;
        
        foreach ($osm_data['elements'] as $element) {
            if (isset($element['tags'])) {
                $tags = $element['tags'];
                
                // Count buildings
                if (isset($tags['building'])) {
                    $building_count++;
                }
                
                // Count roads (excluding paths and tracks)
                if (isset($tags['highway']) && !in_array($tags['highway'], ['path', 'track', 'footway'])) {
                    $road_count++;
                }
                
                // Count amenities
                if (isset($tags['amenity'])) {
                    $amenity_count++;
                }
                
                // Check for commercial land use
                if (isset($tags['landuse']) && in_array($tags['landuse'], ['commercial', 'retail', 'industrial'])) {
                    $commercial_landuse++;
                }
            }
        }
        
        // Calculate density score (0-1)
        $total_elements = count($osm_data['elements']);
        if ($total_elements === 0) {
            return 0.1;
        }
        
        // Weighted scoring
        $building_score = min($building_count / 50, 1.0) * 0.4; // 40% weight
        $road_score = min($road_count / 20, 1.0) * 0.3; // 30% weight
        $amenity_score = min($amenity_count / 10, 1.0) * 0.2; // 20% weight
        $commercial_score = min($commercial_landuse / 5, 1.0) * 0.1; // 10% weight
        
        return $building_score + $road_score + $amenity_score + $commercial_score;
    }
}

// Hook for background processing
add_action('tnpoi_process_sync', array('TNPOI_Sync', 'process_sync'), 10, 2); 