<div class="wrap tnpoi-poi-manager">
    <h1>POI Manager</h1>
    <p>Manage your imported POIs here. Advanced filtering, bulk actions, and inline editing coming soon.</p>
</div> 