<div class="wrap tnpoi-settings">
    <h1>Settings</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields('tnpoi_settings_group');
        do_settings_sections('tnpoi_settings');
        submit_button();
        ?>
    </form>
</div> 