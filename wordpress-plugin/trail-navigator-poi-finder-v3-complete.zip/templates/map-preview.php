<div class="wrap tnpoi-map-preview">
    <h1>Map Preview</h1>
    <p>Visualize your trails and POIs on an interactive map. Leaflet.js integration coming soon.</p>
</div> 