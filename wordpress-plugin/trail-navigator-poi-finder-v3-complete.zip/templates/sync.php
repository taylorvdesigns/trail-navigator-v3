<div class="wrap tnpoi-sync">
    <h1>Sync POIs</h1>
    <p>Import POIs from Google Places for your trails. AJAX sync and progress tracking coming soon.</p>
</div> 