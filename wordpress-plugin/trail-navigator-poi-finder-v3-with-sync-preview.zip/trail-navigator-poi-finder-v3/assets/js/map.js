/**
 * Trail Navigator POI Finder - Map JavaScript
 * 
 * Handles map functionality and POI visualization
 */

(function($) {
    'use strict';
    
    // Global variables
    var map;
    var markers = [];
    var currentMarkers = [];
    var searchAreaCircles = [];
    var syncPreviewData = null;
    var categoryColors = {
        'restaurant': '#e74c3c',
        'cafe': '#f39c12',
        'lodging': '#3498db',
        'park': '#27ae60',
        'museum': '#9b59b6',
        'library': '#34495e',
        'pharmacy': '#e67e22',
        'atm': '#95a5a6',
        'bank': '#16a085',
        'gas_station': '#f1c40f',
        'store': '#1abc9c',
        'tourist_attraction': '#e91e63',
        'default': '#7f8c8d'
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        if ($('#poi-map').length) {
            initializeMap();
            setupEventListeners();
        }
    });
    
    /**
     * Initialize the map
     */
    function initializeMap() {
        // Create map centered on default location
        map = L.map('poi-map').setView([39.8283, -98.5795], 4);
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Load POIs
        loadPOIs();
    }
    
    /**
     * Load POIs from server
     */
    function loadPOIs(filters) {
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_pois',
                nonce: tnpoi_map_ajax.nonce,
                filters: filters || {}
            },
            success: function(response) {
                if (response.success) {
                    addPOIMarkers(response.data);
                } else {
                    console.error('Failed to load POIs:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    }
    
    /**
     * Add POI markers to map
     */
    function addPOIMarkers(pois) {
        // Clear existing markers
        clearMarkers();
        
        pois.forEach(function(poi) {
            var markerColor = categoryColors[poi.category.toLowerCase()] || categoryColors['default'];
            var markerIcon = L.divIcon({
                className: 'poi-marker',
                html: '<div style="background-color: ' + markerColor + '; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [12, 12],
                iconAnchor: [6, 6]
            });
            
            var marker = L.marker([poi.latitude, poi.longitude], {icon: markerIcon})
                .addTo(map)
                .bindPopup(createPopupContent(poi));
            
            // Store marker reference
            marker.poiData = poi;
            markers.push(marker);
            currentMarkers.push(marker);
        });
        
        // Update visible count
        updatePOICount();
        
        // Fit map to show all POIs
        if (currentMarkers.length > 0) {
            fitMapToPOIs();
        }
    }
    
    /**
     * Create popup content for POI
     */
    function createPopupContent(poi) {
        return '<div class="poi-popup">' +
               '<h3>' + poi.name + '</h3>' +
               '<p><strong>Category:</strong> ' + poi.category + '</p>' +
               '<p><strong>Trail:</strong> ' + poi.trail_name + '</p>' +
               '<p><strong>Address:</strong> ' + poi.address + '</p>' +
               '<p><strong>Status:</strong> ' + poi.status + '</p>' +
               '<button type="button" class="button view-details-btn" data-poi-id="' + poi.id + '">View Details</button>' +
               '</div>';
    }
    
    /**
     * Clear all markers from map
     */
    function clearMarkers() {
        currentMarkers.forEach(function(marker) {
            map.removeLayer(marker);
        });
        currentMarkers = [];
    }
    
    /**
     * Fit map to show all POIs
     */
    function fitMapToPOIs() {
        if (currentMarkers.length > 0) {
            var group = new L.featureGroup(currentMarkers);
            map.fitBounds(group.getBounds().pad(0.1));
        }
    }
    
    /**
     * Update POI count display
     */
    function updatePOICount() {
        $('#visible-pois').text(currentMarkers.length);
    }
    
    /**
     * Clear all filters
     */
    function clearFilters() {
        $('#map-search').val('');
        $('#map-type-filter').val('');
        $('#show-hotspots').val('none');
        applyFilters();
    }
    
    /**
     * Apply filters to POIs
     */
    function applyFilters() {
        var filters = {
            search: $('#map-search').val(),
            category: $('#map-type-filter').val(),
            trail: $('#trail-selector').val()
        };
        
        // Filter markers
        clearMarkers();
        
        markers.forEach(function(marker) {
            var poi = marker.poiData;
            var show = true;
            
            if (filters.search && !poi.name.toLowerCase().includes(filters.search.toLowerCase())) {
                show = false;
            }
            
            if (filters.category && poi.category !== filters.category) {
                show = false;
            }
            
            if (filters.trail && poi.trail_name !== filters.trail) {
                show = false;
            }
            
            if (show) {
                map.addLayer(marker);
                currentMarkers.push(marker);
            }
        });
        
        updatePOICount();
        
        if (currentMarkers.length > 0) {
            fitMapToPOIs();
        }
    }
    
    /**
     * Show POI details in modal
     */
    function showPOIDetails(poiId) {
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_poi_details',
                nonce: tnpoi_map_ajax.nonce,
                poi_id: poiId
            },
            success: function(response) {
                if (response.success) {
                    var poi = response.data;
                    var content = '<div class="poi-detail">' +
                                 '<h3>' + poi.name + '</h3>' +
                                 '<table class="poi-detail-table">' +
                                 '<tr><td><strong>Category:</strong></td><td>' + poi.category + '</td></tr>' +
                                 '<tr><td><strong>Trail:</strong></td><td>' + poi.trail_name + '</td></tr>' +
                                 '<tr><td><strong>Address:</strong></td><td>' + poi.address + '</td></tr>' +
                                 '<tr><td><strong>Coordinates:</strong></td><td>' + poi.latitude + ', ' + poi.longitude + '</td></tr>' +
                                 '<tr><td><strong>Status:</strong></td><td>' + poi.status + '</td></tr>' +
                                 '</table>';
                    
                    if (poi.description) {
                        content += '<div class="poi-description"><strong>Description:</strong><p>' + poi.description + '</p></div>';
                    }
                    
                    content += '</div>';
                    
                    $('#poi-details-content').html(content);
                    $('#poi-details-modal').show();
                } else {
                    alert('Failed to load POI details');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                alert('Error loading POI details');
            }
        });
    }
    
    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Mode switching
        $('input[name="map-mode"]').on('change', function() {
            var mode = $(this).val();
            switchMapMode(mode);
        });
        
        // POI view controls
        $('#apply-map-filters').on('click', applyFilters);
        $('#clear-map-filters').on('click', clearFilters);
        $('#fit-bounds').on('click', fitMapToPOIs);
        
        // Sync preview controls
        $('#update-sync-preview').on('click', updateSyncPreview);
        $('#start-sync-from-preview').on('click', startSyncFromPreview);
        $('#fit-trail-bounds').on('click', fitTrailBounds);
        
        // POI details modal
        $(document).on('click', '.view-details-btn', function() {
            var poiId = $(this).data('poi-id');
            showPOIDetails(poiId);
        });
        
        $(document).on('click', '.tnpoi-modal-close', function() {
            $('#poi-details-modal').hide();
        });
    }
    
    /**
     * Switch between POI view and sync preview modes
     */
    function switchMapMode(mode) {
        if (mode === 'poi-view') {
            $('#poi-view-controls').show();
            $('#sync-preview-controls').hide();
            $('#sync-preview-stats').hide();
            $('.tnpoi-stat:not(#sync-preview-stats)').show();
            
            // Clear sync preview elements
            clearSearchAreas();
            loadPOIs();
        } else if (mode === 'sync-preview') {
            $('#poi-view-controls').hide();
            $('#sync-preview-controls').show();
            $('#sync-preview-stats').show();
            $('.tnpoi-stat:not(#sync-preview-stats)').hide();
            
            // Clear POI markers and load sync preview
            clearMarkers();
            loadSyncPreview();
        }
    }
    
    /**
     * Load sync preview data
     */
    function loadSyncPreview() {
        var trailId = $('#trail-selector').val();
        var searchRadius = $('#search-radius').val();
        
        if (!trailId) {
            alert('Please select a trail first');
            return;
        }
        
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_sync_preview',
                nonce: tnpoi_map_ajax.nonce,
                trail_id: trailId,
                search_radius: searchRadius
            },
            success: function(response) {
                if (response.success) {
                    syncPreviewData = response.data;
                    displaySyncPreview(syncPreviewData);
                } else {
                    console.error('Failed to load sync preview:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    }
    
    /**
     * Display sync preview on map
     */
    function displaySyncPreview(data) {
        clearSearchAreas();
        
        // Add sampled points as markers
        data.sampled_points.forEach(function(point, index) {
            var markerIcon = L.divIcon({
                className: 'sampled-point-marker',
                html: '<div style="background-color: #0073aa; width: 8px; height: 8px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [8, 8],
                iconAnchor: [4, 4]
            });
            
            var marker = L.marker([point.lat, point.lng], {icon: markerIcon})
                .addTo(map)
                .bindPopup('Sampled Point ' + (index + 1) + '<br>Search Radius: ' + point.search_radius + 'm');
            
            currentMarkers.push(marker);
            
            // Add search radius circle
            var circle = L.circle([point.lat, point.lng], {
                color: '#0073aa',
                fillColor: '#0073aa',
                fillOpacity: 0.1,
                radius: point.search_radius
            }).addTo(map);
            
            searchAreaCircles.push(circle);
        });
        
        // Update stats
        $('#sampled-points-display').text(data.total_points);
        $('#api-calls-display').text(data.estimated_api_calls);
        
        // Fit map to show all search areas
        if (currentMarkers.length > 0) {
            fitTrailBounds();
        }
    }
    
    /**
     * Clear search area circles
     */
    function clearSearchAreas() {
        searchAreaCircles.forEach(function(circle) {
            map.removeLayer(circle);
        });
        searchAreaCircles = [];
    }
    
    /**
     * Update sync preview with new parameters
     */
    function updateSyncPreview() {
        loadSyncPreview();
    }
    
    /**
     * Start sync from preview
     */
    function startSyncFromPreview() {
        if (!syncPreviewData) {
            alert('Please load sync preview first');
            return;
        }
        
        if (confirm('Start POI sync with current preview settings? This will make approximately ' + syncPreviewData.estimated_api_calls + ' API calls.')) {
            // Redirect to sync page with parameters
            var params = new URLSearchParams({
                trail_id: syncPreviewData.trail_id,
                search_radius: syncPreviewData.search_radius
            });
            
            window.location.href = 'admin.php?page=tnpoi-sync&' + params.toString();
        }
    }
    
    /**
     * Fit map to trail bounds
     */
    function fitTrailBounds() {
        if (currentMarkers.length > 0) {
            var group = new L.featureGroup(currentMarkers);
            map.fitBounds(group.getBounds().pad(0.1));
        }
    }
    
    // Export functions for global access
    window.TNPOIMap = {
        initializeMap: initializeMap,
        loadPOIs: loadPOIs,
        applyFilters: applyFilters,
        showPOIDetails: showPOIDetails,
        fitMapToPOIs: fitMapToPOIs
    };
    
})(jQuery);
