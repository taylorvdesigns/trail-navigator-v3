/**
 * Trail Navigator POI Finder - Map JavaScript
 * 
 * Handles map functionality and trail visualization
 */

(function($) {
    'use strict';
    
    console.log('TNPOI Map JS: Script loaded');
    
    // Global variables
    var map;
    var trailLine = null;
    var markers = [];
    var searchAreaCircles = [];
    var syncPreviewData = null;
    
    // Initialize when document is ready
    $(document).ready(function() {
        console.log('TNPOI Map JS: Document ready');
        console.log('TNPOI Map JS: Map container exists:', $('#poi-map').length > 0);
        console.log('TNPOI Map JS: Leaflet available:', typeof L !== 'undefined');
        console.log('TNPOI Map JS: jQuery available:', typeof $ !== 'undefined');
        
        if ($('#poi-map').length) {
            if (typeof L === 'undefined') {
                console.error('TNPOI Map JS: Leaflet not loaded!');
                $('#poi-map').html('<div style="padding: 20px; text-align: center; color: red;">Error: Map library not loaded. Please refresh the page.</div>');
                return;
            }
            
            console.log('TNPOI Map JS: Initializing map');
            initializeMap();
            setupEventListeners();
        } else {
            console.log('TNPOI Map JS: No map container found');
        }
    });
    
    /**
     * Initialize the map
     */
    function initializeMap() {
        console.log('TNPOI Map JS: initializeMap called');
        console.log('TNPOI Map JS: tnpoiMapData:', window.tnpoiMapData);
        
        // Get center from PHP data or use default
        var centerLat = 39.8283;
        var centerLng = -98.5795;
        var zoom = 4;
        
        if (window.tnpoiMapData && window.tnpoiMapData.selectedTrail) {
            console.log('TNPOI Map JS: Using trail data for center');
            console.log('TNPOI Map JS: Selected trail:', window.tnpoiMapData.selectedTrail);
            
            // Use trail center if available
            var trail = window.tnpoiMapData.selectedTrail;
            
            // Check different possible property names for track points
            var trackPoints = trail.trackPoints || trail.track_points || trail.points || trail.coordinates || [];
            console.log('TNPOI Map JS: Track points found:', trackPoints.length);
            
            if (trackPoints && trackPoints.length > 0) {
                var firstPoint = trackPoints[0];
                console.log('TNPOI Map JS: First point:', firstPoint);
                
                // Check different possible property names for lat/lng
                var lat = firstPoint.lat || firstPoint.latitude || firstPoint.lat;
                var lng = firstPoint.lng || firstPoint.longitude || firstPoint.lng;
                
                if (lat && lng) {
                    centerLat = parseFloat(lat);
                    centerLng = parseFloat(lng);
                    zoom = 10;
                    console.log('TNPOI Map JS: Trail center:', centerLat, centerLng, zoom);
                } else {
                    console.log('TNPOI Map JS: Could not parse lat/lng from first point');
                }
            } else {
                console.log('TNPOI Map JS: No track points found in trail data');
            }
        } else {
            console.log('TNPOI Map JS: Using default center');
        }
        
        // Create map centered on calculated location
        console.log('TNPOI Map JS: Creating map at:', centerLat, centerLng, zoom);
        map = L.map('poi-map').setView([centerLat, centerLng], zoom);
        
        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        console.log('TNPOI Map JS: Map created successfully');
        
        // Add trail line if trail data is available
        if (window.tnpoiMapData && window.tnpoiMapData.selectedTrail) {
            var trail = window.tnpoiMapData.selectedTrail;
            var trackPoints = trail.trackPoints || trail.track_points || trail.points || trail.coordinates || [];
            
            if (trackPoints && trackPoints.length > 0) {
                console.log('TNPOI Map JS: Adding trail line with', trackPoints.length, 'points');
                addTrailLine(trackPoints);
            } else {
                console.log('TNPOI Map JS: No track points available for trail line');
            }
        } else {
            console.log('TNPOI Map JS: No trail data available');
        }
    }
    
    /**
     * Add trail line to map
     */
    function addTrailLine(trackPoints) {
        if (!trackPoints || trackPoints.length < 2) {
            console.log('TNPOI Map JS: Not enough track points for trail line');
            return;
        }
        
        console.log('TNPOI Map JS: Processing', trackPoints.length, 'track points');
        
        var trailCoords = trackPoints.map(function(point, index) {
            // Check different possible property names for lat/lng
            var lat = point.lat || point.latitude || point.lat;
            var lng = point.lng || point.longitude || point.lng;
            
            if (!lat || !lng) {
                console.log('TNPOI Map JS: Invalid point at index', index, ':', point);
                return null;
            }
            
            return [parseFloat(lat), parseFloat(lng)];
        }).filter(function(coord) {
            return coord !== null;
        });
        
        console.log('TNPOI Map JS: Valid coordinates:', trailCoords.length);
        
        if (trailCoords.length < 2) {
            console.log('TNPOI Map JS: Not enough valid coordinates for trail line');
            return;
        }
        
        trailLine = L.polyline(trailCoords, {
            color: '#2271b1',
            weight: 4,
            opacity: 0.8
        }).addTo(map);
        
        console.log('TNPOI Map JS: Trail line added successfully');
        
        // Fit map to trail bounds
        map.fitBounds(trailLine.getBounds().pad(0.1));
    }
    
    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Mode switching
        $('input[name="map-mode"]').on('change', function() {
            var mode = $(this).val();
            switchMapMode(mode);
        });
        
        // Trail view controls
        $('#fit-trail-bounds').on('click', fitTrailBounds);
        $('#load-pois').on('click', loadPOIs);
        
        // Sync preview controls
        $('#update-sync-preview').on('click', updateSyncPreview);
        $('#start-sync-from-preview').on('click', startSyncFromPreview);
    }
    
    /**
     * Switch between trail view and sync preview modes
     */
    function switchMapMode(mode) {
        if (mode === 'trail-view') {
            $('#trail-view-controls').show();
            $('#sync-preview-controls').hide();
            $('#poi-stats').hide();
            $('#sync-preview-stats').hide();
            
            // Clear sync preview elements
            clearSearchAreas();
        } else if (mode === 'sync-preview') {
            $('#trail-view-controls').hide();
            $('#sync-preview-controls').show();
            $('#poi-stats').hide();
            $('#sync-preview-stats').show();
            
            // Load sync preview
            loadSyncPreview();
        }
    }
    
    /**
     * Fit map to trail bounds
     */
    function fitTrailBounds() {
        if (trailLine) {
            map.fitBounds(trailLine.getBounds().pad(0.1));
        }
    }
    
    /**
     * Load POIs for the selected trail
     */
    function loadPOIs() {
        if (!window.tnpoiMapData || !window.tnpoiMapData.selectedTrail) {
            alert('Please select a trail first');
            return;
        }
        
        var trailId = window.tnpoiMapData.selectedTrail.routeId;
        
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_pois',
                nonce: tnpoi_map_ajax.nonce,
                filters: {
                    trail: trailId
                }
            },
            success: function(response) {
                if (response.success) {
                    addPOIMarkers(response.data);
                    $('#poi-stats').show();
                    $('#poi-count-display').text(response.data.length);
                } else {
                    console.error('Failed to load POIs:', response.data);
                    $('#poi-stats').show();
                    $('#poi-count-display').text('0');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                $('#poi-stats').show();
                $('#poi-count-display').text('0');
            }
        });
    }
    
    /**
     * Add POI markers to map
     */
    function addPOIMarkers(pois) {
        // Clear existing markers
        clearMarkers();
        
        if (!pois || pois.length === 0) {
            console.log('No POIs to display');
            return;
        }
        
        pois.forEach(function(poi) {
            var markerIcon = L.divIcon({
                className: 'poi-marker',
                html: '<div style="background-color: #e74c3c; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [12, 12],
                iconAnchor: [6, 6]
            });
            
            var marker = L.marker([parseFloat(poi.latitude), parseFloat(poi.longitude)], {icon: markerIcon})
                .addTo(map)
                .bindPopup('<div class="poi-popup"><h3>' + poi.name + '</h3><p>' + (poi.address || 'No address') + '</p></div>');
            
            markers.push(marker);
        });
    }
    
    /**
     * Clear all markers from map
     */
    function clearMarkers() {
        markers.forEach(function(marker) {
            map.removeLayer(marker);
        });
        markers = [];
    }
    
    /**
     * Load sync preview data
     */
    function loadSyncPreview() {
        if (!window.tnpoiMapData || !window.tnpoiMapData.selectedTrail) {
            alert('Please select a trail first');
            return;
        }
        
        var trailId = window.tnpoiMapData.selectedTrail.routeId;
        var searchRadius = $('#search-radius').val();
        var coordinateInterval = $('#coordinate-interval').val();
        var enableAdaptive = $('#enable-adaptive-sampling').is(':checked');
        
        console.log('TNPOI Map JS: Loading sync preview with radius:', searchRadius, 'interval:', coordinateInterval, 'adaptive:', enableAdaptive);
        console.log('TNPOI Map JS: Checkbox element exists:', $('#enable-adaptive-sampling').length > 0);
        console.log('TNPOI Map JS: Checkbox checked state:', $('#enable-adaptive-sampling').is(':checked'));
        
        var ajaxData = {
            action: 'tnpoi_get_sync_preview',
            nonce: tnpoi_map_ajax.nonce,
            trail_id: trailId,
            search_radius: searchRadius,
            coordinate_interval: coordinateInterval,
            enable_adaptive: enableAdaptive
        };
        
        console.log('TNPOI Map JS: AJAX data being sent:', ajaxData);
        
        $.ajax({
            url: tnpoi_map_ajax.ajax_url,
            type: 'POST',
            data: ajaxData,
            success: function(response) {
                console.log('TNPOI Map JS: AJAX response received:', response);
                if (response.success) {
                    syncPreviewData = response.data;
                    console.log('TNPOI Map JS: Sync preview loaded:', syncPreviewData);
                    console.log('TNPOI Map JS: Sampled points count:', syncPreviewData.sampled_points ? syncPreviewData.sampled_points.length : 0);
                    if (syncPreviewData.sampled_points && syncPreviewData.sampled_points.length > 0) {
                        console.log('TNPOI Map JS: First sampled point:', syncPreviewData.sampled_points[0]);
                    }
                    displaySyncPreview(syncPreviewData);
                } else {
                    console.error('Failed to load sync preview:', response.data);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    }
    
    /**
     * Display sync preview on map
     */
    function displaySyncPreview(data) {
        console.log('TNPOI Map JS: displaySyncPreview called with data:', data);
        clearSearchAreas();
        
        if (!data || !data.sampled_points || !Array.isArray(data.sampled_points)) {
            console.error('TNPOI Map JS: Invalid data structure for sync preview');
            return;
        }
        
        console.log('TNPOI Map JS: Displaying sync preview with', data.sampled_points.length, 'hotspots');
        console.log('TNPOI Map JS: Adaptive sampling:', data.adaptive_sampling);
        if (data.sampled_points.length > 0) {
            console.log('TNPOI Map JS: Sample data:', data.sampled_points[0]); // Log first point for debugging
        }
        
        // Add sampled points as markers
        data.sampled_points.forEach(function(point, index) {
            // Determine marker size and color based on density
            var markerSize = 10;
            var markerColor = '#0073aa';
            var circleColor = '#0073aa';
            var circleOpacity = 0.15;
            
            console.log('TNPOI Map JS: Processing point', index, 'density_score:', point.density_score, 'search_radius:', point.search_radius);
            
            if (data.adaptive_sampling && point.density_score !== undefined) {
                console.log('TNPOI Map JS: Applying adaptive styling for point', index, 'density:', point.density_score);
                
                // Adjust marker size based on density
                if (point.density_score > 0.7) {
                    markerSize = 14;
                    markerColor = '#e74c3c'; // Red for high density
                    circleColor = '#e74c3c';
                    circleOpacity = 0.2;
                    console.log('TNPOI Map JS: High density styling applied');
                } else if (point.density_score > 0.4) {
                    markerSize = 12;
                    markerColor = '#f39c12'; // Orange for medium density
                    circleColor = '#f39c12';
                    circleOpacity = 0.18;
                    console.log('TNPOI Map JS: Medium density styling applied');
                } else if (point.density_score < 0.2) {
                    markerSize = 8;
                    markerColor = '#27ae60'; // Green for low density
                    circleColor = '#27ae60';
                    circleOpacity = 0.12;
                    console.log('TNPOI Map JS: Low density styling applied');
                }
            } else {
                console.log('TNPOI Map JS: Using default styling (no adaptive sampling or no density score)');
            }
            
            var markerIcon = L.divIcon({
                className: 'sampled-point-marker',
                html: '<div style="background-color: ' + markerColor + '; width: ' + markerSize + 'px; height: ' + markerSize + 'px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
                iconSize: [markerSize, markerSize],
                iconAnchor: [markerSize/2, markerSize/2]
            });
            
            var popupContent = '<div class="hotspot-popup"><strong>Hotspot ' + (index + 1) + '</strong><br>Search Radius: ' + point.search_radius + 'm<br>Coordinates: ' + point.lat.toFixed(6) + ', ' + point.lng.toFixed(6);
            
            if (data.adaptive_sampling && point.density_score !== undefined) {
                var densityLabel = 'Low';
                if (point.density_score > 0.7) densityLabel = 'High';
                else if (point.density_score > 0.4) densityLabel = 'Medium';
                
                popupContent += '<br>Density: ' + densityLabel + ' (' + (point.density_score * 100).toFixed(0) + '%)';
            }
            
            popupContent += '</div>';
            
            var marker = L.marker([point.lat, point.lng], {icon: markerIcon})
                .addTo(map)
                .bindPopup(popupContent);
            
            // Add search radius circle
            var circle = L.circle([point.lat, point.lng], {
                color: circleColor,
                fillColor: circleColor,
                fillOpacity: circleOpacity,
                radius: point.search_radius,
                weight: 2
            }).addTo(map);
            
            searchAreaCircles.push(circle);
        });
        
        // Update stats
        $('#sampled-points-display').text(data.total_points);
        $('#api-calls-display').text(data.estimated_api_calls);
        
        // Fit map to show all hotspots if there are any
        if (data.sampled_points.length > 0) {
            var bounds = L.latLngBounds(data.sampled_points.map(function(point) {
                return [point.lat, point.lng];
            }));
            map.fitBounds(bounds.pad(0.1));
        }
        
        console.log('TNPOI Map JS: Sync preview display complete');
    }
    
    /**
     * Clear search area circles
     */
    function clearSearchAreas() {
        searchAreaCircles.forEach(function(circle) {
            map.removeLayer(circle);
        });
        searchAreaCircles = [];
    }
    
    /**
     * Update sync preview with new parameters
     */
    function updateSyncPreview() {
        loadSyncPreview();
    }
    
    /**
     * Start sync from preview
     */
    function startSyncFromPreview() {
        if (!syncPreviewData) {
            alert('Please load sync preview first');
            return;
        }
        
        if (confirm('Start POI sync with current preview settings? This will make approximately ' + syncPreviewData.estimated_api_calls + ' API calls.')) {
            // Redirect to sync page with parameters
            var params = new URLSearchParams({
                trail_id: syncPreviewData.trail_id,
                search_radius: syncPreviewData.search_radius
            });
            
            window.location.href = 'admin.php?page=tnpoi-sync&' + params.toString();
        }
    }
    
})(jQuery);
