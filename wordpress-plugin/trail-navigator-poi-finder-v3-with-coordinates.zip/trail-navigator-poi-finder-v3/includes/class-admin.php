<?php
/**
 * Admin Class
 * 
 * Handles admin interface, menus, and page rendering
 */

if (!defined('ABSPATH')) {
    exit;
}

class TNPOI_Admin {
    
    private $settings;
    private $sync;
    private $db;
    private $csv_export;
    
    public function __construct() {
        $this->settings = new TNPOI_Settings();
        $this->sync = new TNPOI_Sync();
        $this->db = new TNPOI_POI_DB();
        $this->csv_export = new TNPOI_CSV_Export();
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_tnpoi_get_pois', array($this, 'ajax_get_pois'));
        add_action('wp_ajax_tnpoi_delete_poi', array($this, 'ajax_delete_poi'));
        add_action('wp_ajax_tnpoi_bulk_delete', array($this, 'ajax_bulk_delete'));
        add_action('wp_ajax_tnpoi_update_poi', array($this, 'ajax_update_poi'));
        add_action('wp_ajax_tnpoi_get_poi_details', array($this, 'ajax_get_poi_details'));
        add_action('wp_ajax_tnpoi_save_trail_selection', array($this, 'ajax_save_trail_selection'));
    }
    
    /**
     * Add admin menu pages
     */
    public function add_admin_menu() {
        add_menu_page(
            'Trail Navigator POI Finder',
            'Trail POI Finder',
            'manage_options',
            'trail-navigator-poi-finder',
            array($this, 'render_dashboard_page'),
            'dashicons-location',
            30
        );
        
        add_submenu_page(
            'trail-navigator-poi-finder',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'trail-navigator-poi-finder',
            array($this, 'render_dashboard_page')
        );
        
        add_submenu_page(
            'trail-navigator-poi-finder',
            'POI Manager',
            'POI Manager',
            'manage_options',
            'tnpoi-poi-manager',
            array($this, 'render_poi_manager_page')
        );
        
        add_submenu_page(
            'trail-navigator-poi-finder',
            'Sync POIs',
            'Sync POIs',
            'manage_options',
            'tnpoi-sync',
            array($this, 'render_sync_page')
        );
        
        add_submenu_page(
            'trail-navigator-poi-finder',
            'Map Preview',
            'Map Preview',
            'manage_options',
            'tnpoi-map-preview',
            array($this, 'render_map_preview_page')
        );
        
        add_submenu_page(
            'trail-navigator-poi-finder',
            'Settings',
            'Settings',
            'manage_options',
            'tnpoi-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'trail-navigator-poi-finder') === false && 
            strpos($hook, 'tnpoi-') === false) {
            return;
        }
        
        wp_enqueue_style(
            'tnpoi-admin',
            plugin_dir_url(__FILE__) . '../assets/css/admin.css',
            array(),
            '1.0.0'
        );
        
        wp_enqueue_script(
            'tnpoi-admin',
            plugin_dir_url(__FILE__) . '../assets/js/admin.js',
            array('jquery'),
            '1.0.0',
            true
        );
        
        wp_localize_script('tnpoi-admin', 'tnpoi_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tnpoi_admin_nonce'),
            'sync_nonce' => wp_create_nonce('tnpoi_sync_nonce')
        ));
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard_page() {
        $stats = $this->sync->get_sync_stats();
        $recent_pois = $this->db->get_recent_pois(10);
        
        include plugin_dir_path(__FILE__) . '../templates/dashboard.php';
    }
    
    /**
     * Render POI manager page
     */
    public function render_poi_manager_page() {
        $search_terms = get_option('tnpoi_search_terms', array());
        $place_types = $this->get_place_types();
        
        include plugin_dir_path(__FILE__) . '../templates/poi-manager.php';
    }
    
    /**
     * Render sync page
     */
    public function render_sync_page() {
        $search_terms = get_option('tnpoi_search_terms', array());
        $api_key = get_option('tnpoi_google_places_api_key', '');
        
        include plugin_dir_path(__FILE__) . '../templates/sync.php';
    }
    
    /**
     * Render map preview page
     */
    public function render_map_preview_page() {
        $pois = $this->db->get_all_pois();
        
        include plugin_dir_path(__FILE__) . '../templates/map-preview.php';
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        $this->settings->render_settings_page();
    }
    
    /**
     * AJAX: Get POIs with filtering and pagination
     */
    public function ajax_get_pois() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $page = intval($_POST['page'] ?? 1);
        $per_page = intval($_POST['per_page'] ?? 20);
        $search = sanitize_text_field($_POST['search'] ?? '');
        $filter_type = sanitize_text_field($_POST['filter_type'] ?? '');
        $filter_search_term = sanitize_text_field($_POST['filter_search_term'] ?? '');
        
        $pois = $this->db->get_pois_paginated($page, $per_page, $search, $filter_type, $filter_search_term);
        $total = $this->db->get_pois_count($search, $filter_type, $filter_search_term);
        
        wp_send_json_success(array(
            'pois' => $pois,
            'total' => $total,
            'pages' => ceil($total / $per_page),
            'current_page' => $page
        ));
    }
    
    /**
     * AJAX: Delete single POI
     */
    public function ajax_delete_poi() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_id = intval($_POST['poi_id']);
        
        if ($this->db->delete_poi($poi_id)) {
            wp_send_json_success('POI deleted successfully');
        } else {
            wp_send_json_error('Failed to delete POI');
        }
    }
    
    /**
     * AJAX: Bulk delete POIs
     */
    public function ajax_bulk_delete() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_ids = array_map('intval', $_POST['poi_ids'] ?? array());
        
        if (empty($poi_ids)) {
            wp_send_json_error('No POIs selected');
        }
        
        $deleted = 0;
        foreach ($poi_ids as $poi_id) {
            if ($this->db->delete_poi($poi_id)) {
                $deleted++;
            }
        }
        
        wp_send_json_success("Deleted $deleted POIs successfully");
    }
    
    /**
     * AJAX: Update POI
     */
    public function ajax_update_poi() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_id = intval($_POST['poi_id']);
        $data = array(
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'address' => sanitize_text_field($_POST['address'] ?? ''),
            'latitude' => floatval($_POST['latitude'] ?? 0),
            'longitude' => floatval($_POST['longitude'] ?? 0),
            'rating' => floatval($_POST['rating'] ?? 0),
            'user_ratings_total' => intval($_POST['user_ratings_total'] ?? 0),
            'price_level' => intval($_POST['price_level'] ?? 0),
            'updated_at' => current_time('mysql')
        );
        
        if ($this->db->update_poi($poi_id, $data)) {
            wp_send_json_success('POI updated successfully');
        } else {
            wp_send_json_error('Failed to update POI');
        }
    }
    
    /**
     * AJAX: Get POI details
     */
    public function ajax_get_poi_details() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_id = intval($_POST['poi_id']);
        $poi = $this->db->get_poi($poi_id);
        
        if ($poi) {
            wp_send_json_success($poi);
        } else {
            wp_send_json_error('POI not found');
        }
    }
    
    /**
     * AJAX: Save trail selection
     */
    public function ajax_save_trail_selection() {
        check_ajax_referer('tnpoi_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $selected_trails = array_map('sanitize_text_field', $_POST['selected_trails'] ?? array());
        
        if (update_option('tnpoi_selected_trails', $selected_trails)) {
            wp_send_json_success('Trail selection saved successfully');
        } else {
            wp_send_json_error('Failed to save trail selection');
        }
    }
    
    /**
     * Get available place types
     */
    private function get_place_types() {
        return array(
            'restaurant' => 'Restaurant',
            'cafe' => 'Cafe',
            'bar' => 'Bar',
            'lodging' => 'Lodging',
            'gas_station' => 'Gas Station',
            'convenience_store' => 'Convenience Store',
            'pharmacy' => 'Pharmacy',
            'hospital' => 'Hospital',
            'police' => 'Police',
            'fire_station' => 'Fire Station',
            'park' => 'Park',
            'museum' => 'Museum',
            'tourist_attraction' => 'Tourist Attraction',
            'campground' => 'Campground',
            'rv_park' => 'RV Park',
            'bicycle_store' => 'Bicycle Store',
            'bicycle_repair_station' => 'Bicycle Repair Station',
            'parking' => 'Parking',
            'bus_station' => 'Bus Station',
            'train_station' => 'Train Station',
            'subway_station' => 'Subway Station'
        );
    }
} 