<?php
/**
 * Settings Template
 * 
 * Plugin configuration and settings management
 */

if (!defined('ABSPATH')) {
    exit;
}

// Handle form submission
if (isset($_POST['submit']) && wp_verify_nonce($_POST['tnpoi_settings_nonce'], 'tnpoi_save_settings')) {
    $settings = array(
        'google_places_api_key' => sanitize_text_field($_POST['google_places_api_key'] ?? ''),
        'default_radius' => intval($_POST['default_radius'] ?? 1000),
        'default_min_distance' => intval($_POST['default_min_distance'] ?? 100),
        'max_pois_per_sync' => intval($_POST['max_pois_per_sync'] ?? 1000),
        'sync_interval' => intval($_POST['sync_interval'] ?? 24),
        'auto_cleanup_days' => intval($_POST['auto_cleanup_days'] ?? 30),
        'enable_auto_sync' => isset($_POST['enable_auto_sync']),
        'enable_coordinate_thinning' => isset($_POST['enable_coordinate_thinning']),
        'enable_duplicate_check' => isset($_POST['enable_duplicate_check']),
        'default_place_types' => sanitize_text_field($_POST['default_place_types'] ?? ''),
        'export_format' => sanitize_text_field($_POST['export_format'] ?? 'csv'),
        'enable_debug_logging' => isset($_POST['enable_debug_logging'])
    );
    
    update_option('tnpoi_settings', $settings);
    echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
}

$settings = get_option('tnpoi_settings', array());
$defaults = array(
    'google_places_api_key' => '',
    'default_radius' => 1000,
    'default_min_distance' => 100,
    'max_pois_per_sync' => 1000,
    'sync_interval' => 24,
    'auto_cleanup_days' => 30,
    'enable_auto_sync' => false,
    'enable_coordinate_thinning' => true,
    'enable_duplicate_check' => true,
    'default_place_types' => 'restaurant,cafe,gas_station,convenience_store',
    'export_format' => 'csv',
    'enable_debug_logging' => false
);
$settings = wp_parse_args($settings, $defaults);
?>

<div class="wrap tnpoi-settings">
    <h1 class="wp-heading-inline">Trail Navigator POI Finder Settings</h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('tnpoi_save_settings', 'tnpoi_settings_nonce'); ?>
        
        <div class="tnpoi-settings-content">
            <div class="tnpoi-settings-main">
                <!-- API Configuration -->
                <div class="tnpoi-card">
                    <h2>API Configuration</h2>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label for="google_places_api_key">Google Places API Key:</label>
                            <input type="text" id="google_places_api_key" name="google_places_api_key" 
                                   value="<?php echo esc_attr($settings['google_places_api_key']); ?>" 
                                   class="regular-text" required>
                            <p class="description">
                                Your Google Places API key. <a href="https://developers.google.com/maps/documentation/places/web-service/get-api-key" target="_blank">Get one here</a>.
                            </p>
                        </div>
                    </div>
                </div>
                
                <!-- Sync Configuration -->
                <div class="tnpoi-card">
                    <h2>Sync Configuration</h2>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label for="default_radius">Default Search Radius (meters):</label>
                            <input type="number" id="default_radius" name="default_radius" 
                                   value="<?php echo esc_attr($settings['default_radius']); ?>" 
                                   min="100" max="50000" class="regular-text">
                            <p class="description">Default radius for POI searches (100-50000m)</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <label for="default_min_distance">Default Minimum Distance (meters):</label>
                            <input type="number" id="default_min_distance" name="default_min_distance" 
                                   value="<?php echo esc_attr($settings['default_min_distance']); ?>" 
                                   min="10" max="1000" class="regular-text">
                            <p class="description">Minimum distance between POIs for coordinate thinning</p>
                        </div>
                    </div>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label for="max_pois_per_sync">Maximum POIs per Sync:</label>
                            <input type="number" id="max_pois_per_sync" name="max_pois_per_sync" 
                                   value="<?php echo esc_attr($settings['max_pois_per_sync']); ?>" 
                                   min="100" max="10000" class="regular-text">
                            <p class="description">Limit the number of POIs imported per sync operation</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <label for="sync_interval">Auto Sync Interval (hours):</label>
                            <input type="number" id="sync_interval" name="sync_interval" 
                                   value="<?php echo esc_attr($settings['sync_interval']); ?>" 
                                   min="1" max="168" class="regular-text">
                            <p class="description">How often to run automatic sync (1-168 hours)</p>
                        </div>
                    </div>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label for="default_place_types">Default Place Types:</label>
                            <input type="text" id="default_place_types" name="default_place_types" 
                                   value="<?php echo esc_attr($settings['default_place_types']); ?>" 
                                   class="regular-text">
                            <p class="description">Comma-separated list of default place types to search</p>
                        </div>
                    </div>
                </div>
                
                <!-- Features -->
                <div class="tnpoi-card">
                    <h2>Features</h2>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label>
                                <input type="checkbox" name="enable_auto_sync" 
                                       <?php checked($settings['enable_auto_sync']); ?>>
                                Enable Automatic Sync
                            </label>
                            <p class="description">Automatically sync POIs at the specified interval</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <label>
                                <input type="checkbox" name="enable_coordinate_thinning" 
                                       <?php checked($settings['enable_coordinate_thinning']); ?>>
                                Enable Coordinate Thinning
                            </label>
                            <p class="description">Reduce POI density by removing nearby duplicates</p>
                        </div>
                    </div>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label>
                                <input type="checkbox" name="enable_duplicate_check" 
                                       <?php checked($settings['enable_duplicate_check']); ?>>
                                Enable Duplicate Checking
                            </label>
                            <p class="description">Check for and prevent duplicate POIs during sync</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <label>
                                <input type="checkbox" name="enable_debug_logging" 
                                       <?php checked($settings['enable_debug_logging']); ?>>
                                Enable Debug Logging
                            </label>
                            <p class="description">Log detailed information for troubleshooting</p>
                        </div>
                    </div>
                </div>
                
                <!-- Data Management -->
                <div class="tnpoi-card">
                    <h2>Data Management</h2>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <label for="auto_cleanup_days">Auto Cleanup (days):</label>
                            <input type="number" id="auto_cleanup_days" name="auto_cleanup_days" 
                                   value="<?php echo esc_attr($settings['auto_cleanup_days']); ?>" 
                                   min="1" max="365" class="regular-text">
                            <p class="description">Automatically remove POIs older than this many days</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <label for="export_format">Default Export Format:</label>
                            <select id="export_format" name="export_format" class="regular-text">
                                <option value="csv" <?php selected($settings['export_format'], 'csv'); ?>>CSV</option>
                                <option value="geodirectory" <?php selected($settings['export_format'], 'geodirectory'); ?>>GeoDirectory</option>
                                <option value="json" <?php selected($settings['export_format'], 'json'); ?>>JSON</option>
                            </select>
                            <p class="description">Default format for POI exports</p>
                        </div>
                    </div>
                    
                    <div class="tnpoi-form-row">
                        <div class="tnpoi-form-group">
                            <button type="button" id="cleanup-old-pois" class="button button-secondary">
                                🗑️ Cleanup Old POIs
                            </button>
                            <p class="description">Manually remove POIs older than the specified days</p>
                        </div>
                        
                        <div class="tnpoi-form-group">
                            <button type="button" id="export-all-pois" class="button button-secondary">
                                📊 Export All POIs
                            </button>
                            <p class="description">Export all POIs in the selected format</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="tnpoi-settings-sidebar">
                <!-- Quick Actions -->
                <div class="tnpoi-card">
                    <h3>Quick Actions</h3>
                    <div class="tnpoi-quick-actions">
                        <a href="<?php echo admin_url('admin.php?page=tnpoi-sync'); ?>" class="button button-primary">
                            🔄 Go to Sync
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=tnpoi-poi-manager'); ?>" class="button button-secondary">
                            📋 Manage POIs
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=tnpoi-map-preview'); ?>" class="button button-secondary">
                            🗺️ Map Preview
                        </a>
                    </div>
                </div>
                
                <!-- System Status -->
                <div class="tnpoi-card">
                    <h3>System Status</h3>
                    <div class="tnpoi-status-list">
                        <?php
                        $api_key = $settings['google_places_api_key'];
                        $search_terms = get_option('tnpoi_search_terms', array());
                        $db = new TNPOI_DB();
                        $stats = $db->get_stats();
                        ?>
                        <div class="tnpoi-status-item">
                            <span class="tnpoi-status-label">API Key:</span>
                            <span class="tnpoi-status-value <?php echo !empty($api_key) ? 'status-ok' : 'status-error'; ?>">
                                <?php echo !empty($api_key) ? 'Configured' : 'Missing'; ?>
                            </span>
                        </div>
                        <div class="tnpoi-status-item">
                            <span class="tnpoi-status-label">Database:</span>
                            <span class="tnpoi-status-value status-ok">Ready</span>
                        </div>
                        <div class="tnpoi-status-item">
                            <span class="tnpoi-status-label">Search Terms:</span>
                            <span class="tnpoi-status-value <?php echo !empty($search_terms) ? 'status-ok' : 'status-warning'; ?>">
                                <?php echo count($search_terms); ?> configured
                            </span>
                        </div>
                        <div class="tnpoi-status-item">
                            <span class="tnpoi-status-label">Total POIs:</span>
                            <span class="tnpoi-status-value"><?php echo $stats['total_pois']; ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Help -->
                <div class="tnpoi-card">
                    <h3>Help & Support</h3>
                    <div class="tnpoi-help-content">
                        <h4>Getting Started</h4>
                        <ol>
                            <li>Configure your Google Places API key</li>
                            <li>Set up search terms in the Sync page</li>
                            <li>Run your first sync to import POIs</li>
                            <li>Manage and export POIs as needed</li>
                        </ol>
                        
                        <h4>API Key Setup</h4>
                        <ol>
                            <li>Go to <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a></li>
                            <li>Create a new project or select existing</li>
                            <li>Enable Places API</li>
                            <li>Create credentials (API key)</li>
                            <li>Restrict the key to Places API only</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="tnpoi-settings-footer">
            <input type="submit" name="submit" value="Save Settings" class="button button-primary button-large">
        </div>
    </form>
</div>

<style>
.tnpoi-settings {
    margin: 20px 0;
}

.tnpoi-settings-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
}

.tnpoi-card {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-card h2 {
    margin-top: 0;
    margin-bottom: 20px;
    color: #1d2327;
    border-bottom: 2px solid #2271b1;
    padding-bottom: 10px;
}

.tnpoi-card h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #1d2327;
}

.tnpoi-form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}

.tnpoi-form-group {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-form-group label {
    font-weight: 500;
    color: #1d2327;
}

.tnpoi-form-group .description {
    font-size: 0.9em;
    color: #666;
    margin: 0;
}

.tnpoi-quick-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.tnpoi-status-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.tnpoi-status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;
}

.tnpoi-status-item:last-child {
    border-bottom: none;
}

.tnpoi-status-label {
    font-weight: 500;
    color: #666;
}

.tnpoi-status-value {
    font-weight: 600;
}

.tnpoi-status-value.status-ok {
    color: #46b450;
}

.tnpoi-status-value.status-warning {
    color: #ffb900;
}

.tnpoi-status-value.status-error {
    color: #dc3232;
}

.tnpoi-help-content h4 {
    margin-top: 0;
    margin-bottom: 10px;
    color: #1d2327;
}

.tnpoi-help-content ol,
.tnpoi-help-content ul {
    margin: 0;
    padding-left: 20px;
}

.tnpoi-help-content li {
    margin-bottom: 5px;
    color: #666;
}

.tnpoi-settings-footer {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

@media (max-width: 768px) {
    .tnpoi-settings-content {
        grid-template-columns: 1fr;
    }
    
    .tnpoi-form-row {
        flex-direction: column;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Cleanup old POIs
    $('#cleanup-old-pois').on('click', function() {
        if (confirm('Are you sure you want to cleanup old POIs? This action cannot be undone.')) {
            $.ajax({
                url: tnpoi_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'tnpoi_cleanup_old_pois',
                    nonce: tnpoi_ajax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        alert('Cleanup completed: ' + response.data + ' POIs removed');
                        location.reload();
                    } else {
                        alert('Error during cleanup: ' + response.data);
                    }
                }
            });
        }
    });
    
    // Export all POIs
    $('#export-all-pois').on('click', function() {
        const format = $('#export_format').val();
        const url = tnpoi_ajax.ajax_url + '?action=tnpoi_export_' + format + '&nonce=' + tnpoi_ajax.nonce;
        window.open(url, '_blank');
    });
});
</script> 