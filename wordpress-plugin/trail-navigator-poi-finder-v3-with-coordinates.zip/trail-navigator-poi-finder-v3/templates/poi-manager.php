<?php
/**
 * POI Manager Template
 * 
 * Manage and edit POIs with filtering and bulk operations
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap tnpoi-poi-manager">
    <h1 class="wp-heading-inline">POI Manager</h1>
    <a href="<?php echo admin_url('admin.php?page=tnpoi-sync'); ?>" class="page-title-action">Sync New POIs</a>
    
    <div class="tnpoi-filters">
        <div class="tnpoi-filter-row">
            <div class="tnpoi-filter-group">
                <label for="poi-search">Search:</label>
                <input type="text" id="poi-search" placeholder="Search POIs..." class="regular-text">
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="poi-type-filter">Type:</label>
                <select id="poi-type-filter">
                    <option value="">All Types</option>
                    <?php foreach ($place_types as $type => $label): ?>
                        <option value="<?php echo esc_attr($type); ?>"><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="poi-term-filter">Search Term:</label>
                <select id="poi-term-filter">
                    <option value="">All Terms</option>
                    <?php foreach ($search_terms as $term): ?>
                        <option value="<?php echo esc_attr($term['name']); ?>"><?php echo esc_html($term['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="tnpoi-filter-actions">
                <button type="button" id="apply-filters" class="button">Apply Filters</button>
                <button type="button" id="clear-filters" class="button button-secondary">Clear</button>
            </div>
        </div>
    </div>
    
    <div class="tnpoi-bulk-actions">
        <div class="tnpoi-bulk-controls">
            <label>
                <input type="checkbox" id="select-all-pois"> Select All
            </label>
            <button type="button" id="bulk-delete" class="button button-secondary" disabled>
                Delete Selected (<span id="selected-count">0</span>)
            </button>
            <button type="button" id="bulk-export" class="button button-secondary" disabled>
                Export Selected
            </button>
        </div>
    </div>
    
    <div class="tnpoi-poi-table-container">
        <table class="wp-list-table widefat fixed striped tnpoi-poi-table">
            <thead>
                <tr>
                    <td class="manage-column column-cb check-column">
                        <input type="checkbox" id="cb-select-all-1">
                    </td>
                    <th class="manage-column column-name">Name</th>
                    <th class="manage-column column-address">Address</th>
                    <th class="manage-column column-type">Type</th>
                    <th class="manage-column column-rating">Rating</th>
                    <th class="manage-column column-search-term">Search Term</th>
                    <th class="manage-column column-created">Created</th>
                    <th class="manage-column column-actions">Actions</th>
                </tr>
            </thead>
            <tbody id="poi-table-body">
                <tr>
                    <td colspan="7" class="tnpoi-loading">Loading POIs...</td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="tnpoi-pagination">
        <div class="tnpoi-pagination-info">
            Showing <span id="showing-start">0</span> to <span id="showing-end">0</span> of <span id="total-pois">0</span> POIs
        </div>
        <div class="tnpoi-pagination-controls">
            <button type="button" id="prev-page" class="button" disabled>Previous</button>
            <span class="tnpoi-page-info">Page <span id="current-page">1</span> of <span id="total-pages">1</span></span>
            <button type="button" id="next-page" class="button" disabled>Next</button>
        </div>
    </div>
</div>

<!-- POI Edit Modal -->
<div id="poi-edit-modal" class="tnpoi-modal" style="display: none;">
    <div class="tnpoi-modal-content">
        <div class="tnpoi-modal-header">
            <h2>Edit POI</h2>
            <button type="button" class="tnpoi-modal-close">&times;</button>
        </div>
        <div class="tnpoi-modal-body">
            <form id="poi-edit-form">
                <input type="hidden" id="edit-poi-id">
                
                <div class="tnpoi-form-row">
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-name">Name:</label>
                        <input type="text" id="edit-poi-name" class="regular-text" required>
                    </div>
                </div>
                
                <div class="tnpoi-form-row">
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-address">Address:</label>
                        <textarea id="edit-poi-address" rows="2" class="regular-text"></textarea>
                    </div>
                </div>
                
                <div class="tnpoi-form-row">
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-latitude">Latitude:</label>
                        <input type="number" id="edit-poi-latitude" step="any" class="regular-text" required>
                    </div>
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-longitude">Longitude:</label>
                        <input type="number" id="edit-poi-longitude" step="any" class="regular-text" required>
                    </div>
                </div>
                
                <div class="tnpoi-form-row">
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-rating">Rating:</label>
                        <input type="number" id="edit-poi-rating" min="0" max="5" step="0.1" class="small-text">
                    </div>
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-ratings-total">Total Ratings:</label>
                        <input type="number" id="edit-poi-ratings-total" min="0" class="small-text">
                    </div>
                    <div class="tnpoi-form-group">
                        <label for="edit-poi-price-level">Price Level:</label>
                        <select id="edit-poi-price-level">
                            <option value="0">Free</option>
                            <option value="1">Inexpensive</option>
                            <option value="2">Moderate</option>
                            <option value="3">Expensive</option>
                            <option value="4">Very Expensive</option>
                        </select>
                    </div>
                </div>
            </form>
        </div>
        <div class="tnpoi-modal-footer">
            <button type="button" id="save-poi" class="button button-primary">Save Changes</button>
            <button type="button" class="tnpoi-modal-close button button-secondary">Cancel</button>
        </div>
    </div>
</div>

<style>
.tnpoi-poi-manager {
    margin: 20px 0;
}

.tnpoi-filters {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-filter-row {
    display: flex;
    gap: 20px;
    align-items: end;
    flex-wrap: wrap;
}

.tnpoi-filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-filter-group label {
    font-weight: 500;
    color: #1d2327;
}

.tnpoi-filter-actions {
    display: flex;
    gap: 10px;
    align-items: end;
}

.tnpoi-bulk-actions {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-bulk-controls {
    display: flex;
    gap: 15px;
    align-items: center;
}

.tnpoi-poi-table-container {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-poi-table {
    margin: 0;
}

.tnpoi-poi-table th {
    font-weight: 600;
    color: #1d2327;
}

.tnpoi-poi-table td {
    vertical-align: middle;
}

.tnpoi-poi-name {
    font-weight: 500;
    color: #2271b1;
}

.tnpoi-poi-address {
    color: #666;
    font-size: 0.9em;
}

.tnpoi-poi-type {
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    color: #666;
}

.tnpoi-poi-rating {
    color: #f39c12;
    font-weight: 500;
}

.tnpoi-poi-actions {
    display: flex;
    gap: 5px;
}

.tnpoi-loading {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 40px;
}

.tnpoi-pagination {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 15px 20px;
    margin-top: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-pagination-controls {
    display: flex;
    gap: 10px;
    align-items: center;
}

.tnpoi-page-info {
    font-weight: 500;
    color: #666;
}

/* Modal Styles */
.tnpoi-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tnpoi-modal-content {
    background: #fff;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.tnpoi-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.tnpoi-modal-header h2 {
    margin: 0;
}

.tnpoi-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}

.tnpoi-modal-close:hover {
    color: #000;
}

.tnpoi-modal-body {
    padding: 20px;
}

.tnpoi-modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

.tnpoi-form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}

.tnpoi-form-group {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-form-group label {
    font-weight: 500;
    color: #1d2327;
}

@media (max-width: 768px) {
    .tnpoi-filter-row {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tnpoi-filter-actions {
        justify-content: center;
    }
    
    .tnpoi-bulk-controls {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tnpoi-pagination {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .tnpoi-form-row {
        flex-direction: column;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    let currentPage = 1;
    let totalPages = 1;
    let selectedPois = new Set();
    
    // Load POIs on page load
    loadPois();
    
    // Filter functionality
    $('#apply-filters').on('click', function() {
        currentPage = 1;
        loadPois();
    });
    
    $('#clear-filters').on('click', function() {
        $('#poi-search').val('');
        $('#poi-type-filter').val('');
        $('#poi-term-filter').val('');
        currentPage = 1;
        loadPois();
    });
    
    // Pagination
    $('#prev-page').on('click', function() {
        if (currentPage > 1) {
            currentPage--;
            loadPois();
        }
    });
    
    $('#next-page').on('click', function() {
        if (currentPage < totalPages) {
            currentPage++;
            loadPois();
        }
    });
    
    // Bulk operations
    $('#select-all-pois').on('change', function() {
        const checked = $(this).is(':checked');
        $('.poi-checkbox').prop('checked', checked);
        updateSelectedCount();
    });
    
    $('#bulk-delete').on('click', function() {
        if (selectedPois.size === 0) return;
        
        if (confirm('Are you sure you want to delete ' + selectedPois.size + ' POI(s)?')) {
            bulkDeletePois();
        }
    });
    
    // Modal functionality
    $('.tnpoi-modal-close').on('click', function() {
        $('#poi-edit-modal').hide();
    });
    
    $('#save-poi').on('click', function() {
        savePoi();
    });
    
    function loadPois() {
        const search = $('#poi-search').val();
        const filterType = $('#poi-type-filter').val();
        const filterTerm = $('#poi-term-filter').val();
        
        $('#poi-table-body').html('<tr><td colspan="7" class="tnpoi-loading">Loading POIs...</td></tr>');
        
        $.ajax({
            url: tnpoi_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_pois',
                nonce: tnpoi_ajax.nonce,
                page: currentPage,
                per_page: 20,
                search: search,
                filter_type: filterType,
                filter_search_term: filterTerm
            },
            success: function(response) {
                if (response.success) {
                    renderPois(response.data);
                } else {
                    $('#poi-table-body').html('<tr><td colspan="7" class="tnpoi-loading">Error loading POIs</td></tr>');
                }
            },
            error: function() {
                $('#poi-table-body').html('<tr><td colspan="7" class="tnpoi-loading">Error loading POIs</td></tr>');
            }
        });
    }
    
    function renderPois(data) {
        const tbody = $('#poi-table-body');
        tbody.empty();
        
        if (data.pois.length === 0) {
            tbody.html('<tr><td colspan="7" class="tnpoi-loading">No POIs found</td></tr>');
            return;
        }
        
        data.pois.forEach(function(poi) {
            const row = $('<tr>');
            row.append(`
                <td><input type="checkbox" class="poi-checkbox" value="${poi.id}"></td>
                <td>
                    <div class="tnpoi-poi-name">${poi.name}</div>
                    <div class="tnpoi-poi-address">${poi.address || ''}</div>
                </td>
                <td><span class="tnpoi-poi-type">${poi.types || ''}</span></td>
                <td>
                    ${poi.rating > 0 ? `<span class="tnpoi-poi-rating">⭐ ${poi.rating} (${poi.user_ratings_total})</span>` : 'No rating'}
                </td>
                <td>${poi.search_term || ''}</td>
                <td>${new Date(poi.created_at).toLocaleDateString()}</td>
                <td class="tnpoi-poi-actions">
                    <button type="button" class="button button-small edit-poi" data-poi-id="${poi.id}">Edit</button>
                    <button type="button" class="button button-small button-link-delete delete-poi" data-poi-id="${poi.id}">Delete</button>
                </td>
            `);
            tbody.append(row);
        });
        
        // Update pagination
        totalPages = data.pages;
        updatePagination(data);
        
        // Bind events
        $('.poi-checkbox').on('change', updateSelectedCount);
        $('.edit-poi').on('click', function() {
            const poiId = $(this).data('poi-id');
            loadPoiForEdit(poiId);
        });
        $('.delete-poi').on('click', function() {
            const poiId = $(this).data('poi-id');
            if (confirm('Are you sure you want to delete this POI?')) {
                deletePoi(poiId);
            }
        });
    }
    
    function updatePagination(data) {
        const start = (currentPage - 1) * 20 + 1;
        const end = Math.min(currentPage * 20, data.total);
        
        $('#showing-start').text(start);
        $('#showing-end').text(end);
        $('#total-pois').text(data.total);
        $('#current-page').text(currentPage);
        $('#total-pages').text(totalPages);
        
        $('#prev-page').prop('disabled', currentPage <= 1);
        $('#next-page').prop('disabled', currentPage >= totalPages);
    }
    
    function updateSelectedCount() {
        selectedPois.clear();
        $('.poi-checkbox:checked').each(function() {
            selectedPois.add($(this).val());
        });
        
        $('#selected-count').text(selectedPois.size);
        $('#bulk-delete, #bulk-export').prop('disabled', selectedPois.size === 0);
    }
    
    function loadPoiForEdit(poiId) {
        $.ajax({
            url: tnpoi_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_get_poi_details',
                nonce: tnpoi_ajax.nonce,
                poi_id: poiId
            },
            success: function(response) {
                if (response.success) {
                    const poi = response.data;
                    $('#edit-poi-id').val(poi.id);
                    $('#edit-poi-name').val(poi.name);
                    $('#edit-poi-address').val(poi.address);
                    $('#edit-poi-latitude').val(poi.latitude);
                    $('#edit-poi-longitude').val(poi.longitude);
                    $('#edit-poi-rating').val(poi.rating);
                    $('#edit-poi-ratings-total').val(poi.user_ratings_total);
                    $('#edit-poi-price-level').val(poi.price_level);
                    $('#poi-edit-modal').show();
                }
            }
        });
    }
    
    function savePoi() {
        const poiId = $('#edit-poi-id').val();
        const data = {
            name: $('#edit-poi-name').val(),
            address: $('#edit-poi-address').val(),
            latitude: $('#edit-poi-latitude').val(),
            longitude: $('#edit-poi-longitude').val(),
            rating: $('#edit-poi-rating').val(),
            user_ratings_total: $('#edit-poi-ratings-total').val(),
            price_level: $('#edit-poi-price-level').val()
        };
        
        $.ajax({
            url: tnpoi_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_update_poi',
                nonce: tnpoi_ajax.nonce,
                poi_id: poiId,
                ...data
            },
            success: function(response) {
                if (response.success) {
                    $('#poi-edit-modal').hide();
                    loadPois();
                    alert('POI updated successfully');
                } else {
                    alert('Error updating POI: ' + response.data);
                }
            }
        });
    }
    
    function deletePoi(poiId) {
        $.ajax({
            url: tnpoi_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_delete_poi',
                nonce: tnpoi_ajax.nonce,
                poi_id: poiId
            },
            success: function(response) {
                if (response.success) {
                    loadPois();
                    alert('POI deleted successfully');
                } else {
                    alert('Error deleting POI: ' + response.data);
                }
            }
        });
    }
    
    function bulkDeletePois() {
        $.ajax({
            url: tnpoi_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'tnpoi_bulk_delete',
                nonce: tnpoi_ajax.nonce,
                poi_ids: Array.from(selectedPois)
            },
            success: function(response) {
                if (response.success) {
                    selectedPois.clear();
                    loadPois();
                    alert(response.data);
                } else {
                    alert('Error deleting POIs: ' + response.data);
                }
            }
        });
    }
});
</script> 