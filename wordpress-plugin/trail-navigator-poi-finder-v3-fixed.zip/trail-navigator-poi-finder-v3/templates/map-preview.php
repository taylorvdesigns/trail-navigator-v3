<?php
/**
 * Map Preview Template
 * 
 * Interactive map preview using Leaflet.js with OSM intelligence visualization
 */

if (!defined('ABSPATH')) {
    exit;
}

// Enqueue Leaflet.js
wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);

// Get available trails and selected trail
$trail_config = get_option('trail_navigator_config', array());
$available_trails = isset($trail_config['trails']) ? $trail_config['trails'] : array();
$selected_trail_id = $_GET['trail_id'] ?? '';
$selected_trail = null;

if ($selected_trail_id) {
    foreach ($available_trails as $trail) {
        if ($trail['routeId'] === $selected_trail_id) {
            $selected_trail = $trail;
            break;
        }
    }
}

// Get POIs for selected trail
$pois = array();
if ($selected_trail) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tnpoi_pois';
    $pois = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE trail_id = %s ORDER BY created_at DESC",
        $selected_trail['routeId']
    ), ARRAY_A);
}
?>

<div class="wrap tnpoi-map-preview">
    <h1 class="wp-heading-inline">Map Preview</h1>
    <a href="<?php echo admin_url('admin.php?page=tnpoi-poi-manager'); ?>" class="page-title-action">Manage POIs</a>
    
    <!-- Trail Selection -->
    <div class="tnpoi-trail-selection-panel">
        <h3>Select Trail for Preview</h3>
        <form method="get" action="" class="tnpoi-trail-form">
            <input type="hidden" name="page" value="tnpoi-map-preview">
            <select name="trail_id" id="trail-selector" onchange="this.form.submit()">
                <option value="">-- Select a trail --</option>
                <?php foreach ($available_trails as $trail): ?>
                    <option value="<?php echo esc_attr($trail['routeId']); ?>" 
                            <?php selected($selected_trail_id, $trail['routeId']); ?>>
                        <?php echo esc_html($trail['name']); ?> 
                        (<?php echo count($trail['trackPoints'] ?? array()); ?> points)
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        
        <?php if ($selected_trail): ?>
            <div class="tnpoi-trail-info">
                <h4><?php echo esc_html($selected_trail['name']); ?></h4>
                <p><strong>Route ID:</strong> <?php echo esc_html($selected_trail['routeId']); ?></p>
                <p><strong>Track Points:</strong> <?php echo count($selected_trail['trackPoints'] ?? array()); ?></p>
                <p><strong>POIs Found:</strong> <?php echo count($pois); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if ($selected_trail): ?>
    <div class="tnpoi-map-controls">
        <!-- Mode Toggle -->
        <div class="tnpoi-mode-toggle">
            <label class="tnpoi-mode-option">
                <input type="radio" name="map-mode" value="poi-view" checked>
                <span>POI View</span>
            </label>
            <label class="tnpoi-mode-option">
                <input type="radio" name="map-mode" value="sync-preview">
                <span>Sync Preview</span>
            </label>
        </div>
        
        <!-- POI View Controls (existing) -->
        <div class="tnpoi-map-filters" id="poi-view-controls">
            <div class="tnpoi-filter-group">
                <label for="map-search">Search POIs:</label>
                <input type="text" id="map-search" placeholder="Search by name..." class="regular-text">
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="map-type-filter">Filter by Type:</label>
                <select id="map-type-filter">
                    <option value="">All Types</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="cafe">Cafe</option>
                    <option value="bar">Bar</option>
                    <option value="lodging">Lodging</option>
                    <option value="gas_station">Gas Station</option>
                    <option value="convenience_store">Convenience Store</option>
                    <option value="pharmacy">Pharmacy</option>
                    <option value="hospital">Hospital</option>
                    <option value="police">Police</option>
                    <option value="fire_station">Fire Station</option>
                    <option value="park">Park</option>
                    <option value="museum">Museum</option>
                    <option value="tourist_attraction">Tourist Attraction</option>
                    <option value="campground">Campground</option>
                    <option value="rv_park">RV Park</option>
                    <option value="bicycle_store">Bicycle Store</option>
                    <option value="bicycle_repair_station">Bicycle Repair Station</option>
                    <option value="parking">Parking</option>
                    <option value="bus_station">Bus Station</option>
                    <option value="train_station">Train Station</option>
                    <option value="subway_station">Subway Station</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="show-hotspots">Show Hotspots:</label>
                <select id="show-hotspots">
                    <option value="none">None</option>
                    <option value="uniform">Uniform Spacing</option>
                    <option value="osm">OSM Intelligence</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-actions">
                <button type="button" id="apply-map-filters" class="button">Apply Filters</button>
                <button type="button" id="clear-map-filters" class="button button-secondary">Clear</button>
                <button type="button" id="fit-bounds" class="button button-secondary">Fit Trail</button>
            </div>
        </div>
        
        <!-- Sync Preview Controls (new) -->
        <div class="tnpoi-map-filters" id="sync-preview-controls" style="display: none;">
            <div class="tnpoi-filter-group">
                <label for="search-radius">Search Radius (meters):</label>
                <input type="number" id="search-radius" value="500" min="50" max="5000" step="50" class="small-text">
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="coordinate-interval">Coordinate Interval (meters):</label>
                <select id="coordinate-interval">
                    <option value="100">100m (High Density)</option>
                    <option value="200">200m (Medium Density)</option>
                    <option value="300">300m (Low Density)</option>
                    <option value="500">500m (Very Low Density)</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="show-search-areas">Show Search Areas:</label>
                <select id="show-search-areas">
                    <option value="circles">Radius Circles</option>
                    <option value="heatmap">Heat Map</option>
                    <option value="both">Both</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-actions">
                <button type="button" id="update-sync-preview" class="button">Update Preview</button>
                <button type="button" id="start-sync-from-preview" class="button button-primary">Start Sync</button>
                <button type="button" id="fit-trail-bounds" class="button button-secondary">Fit Trail</button>
            </div>
        </div>
        
        <div class="tnpoi-map-stats">
            <span class="tnpoi-stat">Total POIs: <span id="total-pois-display"><?php echo count($pois); ?></span></span>
            <span class="tnpoi-stat">Visible: <span id="visible-pois-display"><?php echo count($pois); ?></span></span>
            <span class="tnpoi-stat">Hotspots: <span id="hotspots-display">-</span></span>
            <!-- Sync Preview Stats -->
            <span class="tnpoi-stat" id="sync-preview-stats" style="display: none;">
                Sampled Points: <span id="sampled-points-display">-</span> | 
                API Calls: <span id="api-calls-display">-</span>
            </span>
        </div>
    </div>
    
    <div class="tnpoi-map-container">
        <div id="poi-map" style="height: 600px; width: 100%;"></div>
    </div>
    
    <div class="tnpoi-map-sidebar">
        <div class="tnpoi-poi-list">
            <h3>POI List</h3>
            <div id="poi-list-container">
                <div class="tnpoi-loading">Loading POIs...</div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="tnpoi-no-trail-selected">
        <p>Please select a trail above to view the map preview and OSM intelligence visualization.</p>
    </div>
    <?php endif; ?>
</div>

<!-- POI Details Modal -->
<div id="poi-details-modal" class="tnpoi-modal" style="display: none;">
    <div class="tnpoi-modal-content">
        <div class="tnpoi-modal-header">
            <h2>POI Details</h2>
            <button type="button" class="tnpoi-modal-close">&times;</button>
        </div>
        <div class="tnpoi-modal-body">
            <div id="poi-details-content">
                <!-- POI details will be loaded here -->
            </div>
        </div>
        <div class="tnpoi-modal-footer">
            <button type="button" class="tnpoi-modal-close button button-secondary">Close</button>
        </div>
    </div>
</div>

<!-- Load the map JavaScript -->
<script>
// Pass PHP data to JavaScript
window.tnpoiMapData = {
    pois: <?php echo json_encode($pois); ?>,
    selectedTrail: <?php echo json_encode($selected_trail); ?>,
    availableTrails: <?php echo json_encode($available_trails); ?>
};
</script>

<style>
.tnpoi-map-preview {
    margin: 20px 0;
}

.tnpoi-map-controls {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-mode-toggle {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
}

.tnpoi-mode-option {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border: 2px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tnpoi-mode-option:hover {
    border-color: #0073aa;
    background-color: #f0f8ff;
}

.tnpoi-mode-option input[type="radio"] {
    margin: 0;
}

.tnpoi-mode-option input[type="radio"]:checked + span {
    font-weight: 600;
    color: #0073aa;
}

.tnpoi-mode-option input[type="radio"]:checked ~ .tnpoi-mode-option {
    border-color: #0073aa;
    background-color: #e6f3ff;
}

.tnpoi-map-filters {
    display: flex;
    gap: 20px;
    align-items: end;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.tnpoi-filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-filter-group label {
    font-weight: 500;
    color: #1d2327;
}

.tnpoi-filter-actions {
    display: flex;
    gap: 10px;
    align-items: end;
}

.tnpoi-map-stats {
    display: flex;
    gap: 20px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.tnpoi-stat {
    font-weight: 500;
    color: #666;
}

.tnpoi-stat span {
    color: #2271b1;
    font-weight: 600;
}

.tnpoi-map-container {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.tnpoi-map-sidebar {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-poi-list h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #1d2327;
}

#poi-list-container {
    max-height: 400px;
    overflow-y: auto;
}

.tnpoi-poi-list-item {
    padding: 10px;
    border: 1px solid #f0f0f0;
    border-radius: 6px;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tnpoi-poi-list-item:hover {
    background: #f9f9f9;
    border-color: #2271b1;
}

.tnpoi-poi-list-item.selected {
    background: #e7f3ff;
    border-color: #2271b1;
}

.tnpoi-poi-list-item h4 {
    margin: 0 0 5px 0;
    color: #2271b1;
    font-size: 1em;
}

.tnpoi-poi-list-item p {
    margin: 0;
    color: #666;
    font-size: 0.9em;
}

.tnpoi-poi-meta {
    display: flex;
    gap: 10px;
    margin-top: 5px;
    font-size: 0.8em;
    color: #888;
}

.tnpoi-loading {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 20px;
}

/* Leaflet customizations */
.leaflet-popup-content {
    margin: 10px;
    min-width: 200px;
}

.leaflet-popup-content h3 {
    margin: 0 0 10px 0;
    color: #2271b1;
}

.leaflet-popup-content p {
    margin: 5px 0;
    color: #666;
}

.leaflet-popup-content .poi-rating {
    color: #f39c12;
    font-weight: 500;
}

.leaflet-popup-content .poi-type {
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    color: #666;
    display: inline-block;
    margin-top: 5px;
}

/* Modal Styles */
.tnpoi-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tnpoi-modal-content {
    background: #fff;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.tnpoi-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.tnpoi-modal-header h2 {
    margin: 0;
}

.tnpoi-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}

.tnpoi-modal-close:hover {
    color: #000;
}

.tnpoi-modal-body {
    padding: 20px;
}

.tnpoi-modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

@media (max-width: 768px) {
    .tnpoi-map-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tnpoi-filter-actions {
        justify-content: center;
    }
    
    .tnpoi-map-stats {
        flex-direction: column;
        gap: 10px;
    }
    
    #poi-map {
        height: 400px;
    }
}
</style> 