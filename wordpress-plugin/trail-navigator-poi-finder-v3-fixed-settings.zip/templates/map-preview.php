<?php
/**
 * Map Preview Template
 * 
 * Interactive map preview using Leaflet.js
 */

if (!defined('ABSPATH')) {
    exit;
}

// Enqueue Leaflet.js
wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css');
wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
?>

<div class="wrap tnpoi-map-preview">
    <h1 class="wp-heading-inline">Map Preview</h1>
    <a href="<?php echo admin_url('admin.php?page=tnpoi-poi-manager'); ?>" class="page-title-action">Manage POIs</a>
    
    <div class="tnpoi-map-controls">
        <div class="tnpoi-map-filters">
            <div class="tnpoi-filter-group">
                <label for="map-search">Search POIs:</label>
                <input type="text" id="map-search" placeholder="Search by name..." class="regular-text">
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="map-type-filter">Filter by Type:</label>
                <select id="map-type-filter">
                    <option value="">All Types</option>
                    <option value="restaurant">Restaurant</option>
                    <option value="cafe">Cafe</option>
                    <option value="bar">Bar</option>
                    <option value="lodging">Lodging</option>
                    <option value="gas_station">Gas Station</option>
                    <option value="convenience_store">Convenience Store</option>
                    <option value="pharmacy">Pharmacy</option>
                    <option value="hospital">Hospital</option>
                    <option value="police">Police</option>
                    <option value="fire_station">Fire Station</option>
                    <option value="park">Park</option>
                    <option value="museum">Museum</option>
                    <option value="tourist_attraction">Tourist Attraction</option>
                    <option value="campground">Campground</option>
                    <option value="rv_park">RV Park</option>
                    <option value="bicycle_store">Bicycle Store</option>
                    <option value="bicycle_repair_station">Bicycle Repair Station</option>
                    <option value="parking">Parking</option>
                    <option value="bus_station">Bus Station</option>
                    <option value="train_station">Train Station</option>
                    <option value="subway_station">Subway Station</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-group">
                <label for="map-radius-filter">Show within radius:</label>
                <select id="map-radius-filter">
                    <option value="0">All POIs</option>
                    <option value="1000">1 km</option>
                    <option value="5000">5 km</option>
                    <option value="10000">10 km</option>
                    <option value="25000">25 km</option>
                </select>
            </div>
            
            <div class="tnpoi-filter-actions">
                <button type="button" id="apply-map-filters" class="button">Apply Filters</button>
                <button type="button" id="clear-map-filters" class="button button-secondary">Clear</button>
                <button type="button" id="fit-bounds" class="button button-secondary">Fit All POIs</button>
            </div>
        </div>
        
        <div class="tnpoi-map-stats">
            <span class="tnpoi-stat">Total POIs: <span id="total-pois-display"><?php echo count($pois); ?></span></span>
            <span class="tnpoi-stat">Visible: <span id="visible-pois-display"><?php echo count($pois); ?></span></span>
            <span class="tnpoi-stat">Selected: <span id="selected-pois-display">0</span></span>
        </div>
    </div>
    
    <div class="tnpoi-map-container">
        <div id="poi-map" style="height: 600px; width: 100%;"></div>
    </div>
    
    <div class="tnpoi-map-sidebar">
        <div class="tnpoi-poi-list">
            <h3>POI List</h3>
            <div id="poi-list-container">
                <div class="tnpoi-loading">Loading POIs...</div>
            </div>
        </div>
    </div>
</div>

<!-- POI Details Modal -->
<div id="poi-details-modal" class="tnpoi-modal" style="display: none;">
    <div class="tnpoi-modal-content">
        <div class="tnpoi-modal-header">
            <h2>POI Details</h2>
            <button type="button" class="tnpoi-modal-close">&times;</button>
        </div>
        <div class="tnpoi-modal-body">
            <div id="poi-details-content">
                <!-- POI details will be loaded here -->
            </div>
        </div>
        <div class="tnpoi-modal-footer">
            <button type="button" class="tnpoi-modal-close button button-secondary">Close</button>
        </div>
    </div>
</div>

<style>
.tnpoi-map-preview {
    margin: 20px 0;
}

.tnpoi-map-controls {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-map-filters {
    display: flex;
    gap: 20px;
    align-items: end;
    flex-wrap: wrap;
    margin-bottom: 15px;
}

.tnpoi-filter-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.tnpoi-filter-group label {
    font-weight: 500;
    color: #1d2327;
}

.tnpoi-filter-actions {
    display: flex;
    gap: 10px;
    align-items: end;
}

.tnpoi-map-stats {
    display: flex;
    gap: 20px;
    padding-top: 15px;
    border-top: 1px solid #f0f0f0;
}

.tnpoi-stat {
    font-weight: 500;
    color: #666;
}

.tnpoi-stat span {
    color: #2271b1;
    font-weight: 600;
}

.tnpoi-map-container {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.tnpoi-map-sidebar {
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.tnpoi-poi-list h3 {
    margin-top: 0;
    margin-bottom: 15px;
    color: #1d2327;
}

#poi-list-container {
    max-height: 400px;
    overflow-y: auto;
}

.tnpoi-poi-list-item {
    padding: 10px;
    border: 1px solid #f0f0f0;
    border-radius: 6px;
    margin-bottom: 10px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.tnpoi-poi-list-item:hover {
    background: #f9f9f9;
    border-color: #2271b1;
}

.tnpoi-poi-list-item.selected {
    background: #e7f3ff;
    border-color: #2271b1;
}

.tnpoi-poi-list-item h4 {
    margin: 0 0 5px 0;
    color: #2271b1;
    font-size: 1em;
}

.tnpoi-poi-list-item p {
    margin: 0;
    color: #666;
    font-size: 0.9em;
}

.tnpoi-poi-meta {
    display: flex;
    gap: 10px;
    margin-top: 5px;
    font-size: 0.8em;
    color: #888;
}

.tnpoi-loading {
    text-align: center;
    color: #666;
    font-style: italic;
    padding: 20px;
}

/* Leaflet customizations */
.leaflet-popup-content {
    margin: 10px;
    min-width: 200px;
}

.leaflet-popup-content h3 {
    margin: 0 0 10px 0;
    color: #2271b1;
}

.leaflet-popup-content p {
    margin: 5px 0;
    color: #666;
}

.leaflet-popup-content .poi-rating {
    color: #f39c12;
    font-weight: 500;
}

.leaflet-popup-content .poi-type {
    background: #f0f0f0;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    color: #666;
    display: inline-block;
    margin-top: 5px;
}

/* Modal Styles */
.tnpoi-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 100000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tnpoi-modal-content {
    background: #fff;
    border-radius: 8px;
    max-width: 600px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
}

.tnpoi-modal-header {
    padding: 20px;
    border-bottom: 1px solid #ddd;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.tnpoi-modal-header h2 {
    margin: 0;
}

.tnpoi-modal-close {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
}

.tnpoi-modal-close:hover {
    color: #000;
}

.tnpoi-modal-body {
    padding: 20px;
}

.tnpoi-modal-footer {
    padding: 20px;
    border-top: 1px solid #ddd;
    display: flex;
    gap: 10px;
    justify-content: flex-end;
}

@media (max-width: 768px) {
    .tnpoi-map-filters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tnpoi-filter-actions {
        justify-content: center;
    }
    
    .tnpoi-map-stats {
        flex-direction: column;
        gap: 10px;
    }
    
    #poi-map {
        height: 400px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    let map;
    let markers = [];
    let pois = <?php echo json_encode($pois); ?>;
    let filteredPois = pois;
    let selectedPois = new Set();
    let currentCenter = null;
    let currentRadius = 0;
    
    // Initialize map
    initMap();
    
    // Load POIs
    loadPois();
    
    // Filter functionality
    $('#apply-map-filters').on('click', function() {
        applyFilters();
    });
    
    $('#clear-map-filters').on('click', function() {
        clearFilters();
    });
    
    $('#fit-bounds').on('click', function() {
        fitAllPois();
    });
    
    // Modal functionality
    $('.tnpoi-modal-close').on('click', function() {
        $('#poi-details-modal').hide();
    });
    
    function initMap() {
        // Initialize map with default center (first POI or default location)
        const defaultCenter = pois.length > 0 ? 
            [parseFloat(pois[0].latitude), parseFloat(pois[0].longitude)] : 
            [40.7128, -74.0060]; // Default to NYC
        
        map = L.map('poi-map').setView(defaultCenter, 12);
        
        // Add tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(map);
        
        // Add radius circle (initially hidden)
        currentCenter = L.circle(defaultCenter, {
            color: 'red',
            fillColor: '#f03',
            fillOpacity: 0.2,
            radius: 1000
        }).addTo(map);
        currentCenter.setRadius(0);
    }
    
    function loadPois() {
        // Clear existing markers
        markers.forEach(marker => map.removeLayer(marker));
        markers = [];
        
        // Add markers for filtered POIs
        filteredPois.forEach(function(poi, index) {
            const marker = L.marker([parseFloat(poi.latitude), parseFloat(poi.longitude)])
                .bindPopup(createPopupContent(poi))
                .addTo(map);
            
            marker.on('click', function() {
                showPoiDetails(poi);
            });
            
            markers.push(marker);
        });
        
        updateStats();
        renderPoiList();
    }
    
    function createPopupContent(poi) {
        const rating = poi.rating > 0 ? 
            `<div class="poi-rating">⭐ ${poi.rating} (${poi.user_ratings_total} reviews)</div>` : '';
        
        const type = poi.types ? 
            `<div class="poi-type">${poi.types}</div>` : '';
        
        return `
            <h3>${poi.name}</h3>
            <p><strong>Address:</strong> ${poi.address || 'N/A'}</p>
            ${rating}
            ${type}
            <p><strong>Search Term:</strong> ${poi.search_term || 'N/A'}</p>
        `;
    }
    
    function showPoiDetails(poi) {
        const rating = poi.rating > 0 ? 
            `<p><strong>Rating:</strong> ⭐ ${poi.rating} (${poi.user_ratings_total} reviews)</p>` : '';
        
        const priceLevel = poi.price_level > 0 ? 
            `<p><strong>Price Level:</strong> ${'$'.repeat(poi.price_level)}</p>` : '';
        
        const content = `
            <h3>${poi.name}</h3>
            <p><strong>Address:</strong> ${poi.address || 'N/A'}</p>
            <p><strong>Coordinates:</strong> ${poi.latitude}, ${poi.longitude}</p>
            <p><strong>Type:</strong> ${poi.types || 'N/A'}</p>
            ${rating}
            ${priceLevel}
            <p><strong>Search Term:</strong> ${poi.search_term || 'N/A'}</p>
            <p><strong>Created:</strong> ${new Date(poi.created_at).toLocaleDateString()}</p>
        `;
        
        $('#poi-details-content').html(content);
        $('#poi-details-modal').show();
    }
    
    function applyFilters() {
        const search = $('#map-search').val().toLowerCase();
        const typeFilter = $('#map-type-filter').val();
        const radiusFilter = parseInt($('#map-radius-filter').val());
        
        filteredPois = pois.filter(function(poi) {
            // Search filter
            if (search && !poi.name.toLowerCase().includes(search) && 
                !(poi.address && poi.address.toLowerCase().includes(search))) {
                return false;
            }
            
            // Type filter
            if (typeFilter && (!poi.types || !poi.types.includes(typeFilter))) {
                return false;
            }
            
            // Radius filter
            if (radiusFilter > 0) {
                const mapCenter = map.getCenter();
                const distance = mapCenter.distanceTo([poi.latitude, poi.longitude]);
                if (distance > radiusFilter) {
                    return false;
                }
            }
            
            return true;
        });
        
        loadPois();
        
        // Update radius circle
        if (radiusFilter > 0) {
            const mapCenter = map.getCenter();
            currentCenter.setLatLng(mapCenter);
            currentCenter.setRadius(radiusFilter);
            currentCenter.setStyle({opacity: 0.3});
        } else {
            currentCenter.setRadius(0);
        }
    }
    
    function clearFilters() {
        $('#map-search').val('');
        $('#map-type-filter').val('');
        $('#map-radius-filter').val('0');
        filteredPois = pois;
        loadPois();
        currentCenter.setRadius(0);
    }
    
    function fitAllPois() {
        if (filteredPois.length === 0) return;
        
        const group = new L.featureGroup(markers);
        map.fitBounds(group.getBounds().pad(0.1));
    }
    
    function renderPoiList() {
        const container = $('#poi-list-container');
        container.empty();
        
        if (filteredPois.length === 0) {
            container.html('<div class="tnpoi-loading">No POIs found</div>');
            return;
        }
        
        filteredPois.forEach(function(poi, index) {
            const rating = poi.rating > 0 ? 
                `<span class="poi-rating">⭐ ${poi.rating}</span>` : '';
            
            const item = $(`
                <div class="tnpoi-poi-list-item" data-index="${index}">
                    <h4>${poi.name}</h4>
                    <p>${poi.address || 'No address'}</p>
                    <div class="tnpoi-poi-meta">
                        <span>${poi.types || 'No type'}</span>
                        ${rating}
                    </div>
                </div>
            `);
            
            item.on('click', function() {
                // Toggle selection
                if (selectedPois.has(index)) {
                    selectedPois.delete(index);
                    item.removeClass('selected');
                } else {
                    selectedPois.add(index);
                    item.addClass('selected');
                }
                updateStats();
                
                // Center map on POI
                const poi = filteredPois[index];
                map.setView([poi.latitude, poi.longitude], 15);
            });
            
            container.append(item);
        });
    }
    
    function updateStats() {
        $('#total-pois-display').text(pois.length);
        $('#visible-pois-display').text(filteredPois.length);
        $('#selected-pois-display').text(selectedPois.size);
    }
});
</script> 