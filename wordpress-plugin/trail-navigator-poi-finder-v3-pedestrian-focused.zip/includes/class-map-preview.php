<?php
/**
 * Map Preview Class
 * 
 * Handles map functionality and POI visualization using Leaflet.js
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class TNPOI_Map_Preview {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Enqueue map scripts and styles
     */
    public function enqueue_scripts() {
        // Only enqueue on our plugin pages
        if (!$this->is_plugin_page()) {
            return;
        }
        
        // Enqueue Leaflet.js
        wp_enqueue_script(
            'leaflet-js',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
            array(),
            '1.9.4',
            true
        );
        
        wp_enqueue_style(
            'leaflet-css',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
            array(),
            '1.9.4'
        );
        
        // Enqueue our custom map script
        wp_enqueue_script(
            'tnpoi-map',
            TNPOI_PLUGIN_URL . 'assets/js/map.js',
            array('leaflet-js', 'jquery'),
            TNPOI_VERSION,
            true
        );
        
        // Localize script with AJAX URL and nonce
        wp_localize_script('tnpoi-map', 'tnpoi_map_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tnpoi_map_nonce'),
            'plugin_url' => TNPOI_PLUGIN_URL
        ));
    }
    
    /**
     * Check if current page is a plugin page
     */
    private function is_plugin_page() {
        $screen = get_current_screen();
        if (!$screen) {
            return false;
        }
        
        // Debug: Log the current screen ID
        error_log('TNPOI Map Preview: Current screen ID: ' . $screen->id);
        
        $plugin_pages = array(
            'toplevel_page_tnpoi-dashboard',
            'trail-navigator_page_tnpoi-poi-manager',
            'trail-navigator_page_tnpoi-sync',
            'trail-navigator_page_tnpoi-map-preview',
            'trail-navigator_page_tnpoi-settings',
            // Add more generic patterns
            'tnpoi',
            'trail-navigator'
        );
        
        $is_plugin_page = false;
        foreach ($plugin_pages as $page) {
            if (strpos($screen->id, $page) !== false) {
                $is_plugin_page = true;
                break;
            }
        }
        
        error_log('TNPOI Map Preview: Is plugin page: ' . ($is_plugin_page ? 'true' : 'false'));
        return $is_plugin_page;
    }
    
    /**
     * Get POIs for map display
     */
    public function get_pois_for_map($filters = array()) {
        $poi_db = new TNPOI_POI_DB();
        
        $search = isset($filters['search']) ? sanitize_text_field($filters['search']) : '';
        $category = isset($filters['category']) ? sanitize_text_field($filters['category']) : '';
        $trail = isset($filters['trail']) ? sanitize_text_field($filters['trail']) : '';
        $status = isset($filters['status']) ? sanitize_text_field($filters['status']) : '';
        
        $pois = $poi_db->get_pois(1, 1000, $search, $category, $trail, $status);
        
        $map_pois = array();
        foreach ($pois as $poi) {
            $map_pois[] = array(
                'id' => $poi->id,
                'name' => $poi->name,
                'category' => $poi->category ?: 'Uncategorized',
                'trail_name' => $poi->trail_name ?: 'Unknown Trail',
                'address' => $poi->address,
                'latitude' => floatval($poi->latitude),
                'longitude' => floatval($poi->longitude),
                'status' => $poi->status,
                'description' => $poi->description,
                'place_id' => $poi->place_id
            );
        }
        
        return $map_pois;
    }
    
    /**
     * Get map configuration
     */
    public function get_map_config() {
        $settings = get_option('tnpoi_settings', array());
        
        return array(
            'center_lat' => $settings['default_map_center_lat'] ?? 39.8283,
            'center_lng' => $settings['default_map_center_lng'] ?? -98.5795,
            'zoom' => $settings['default_map_zoom'] ?? 4,
            'tile_provider' => $settings['map_tile_provider'] ?? 'openstreetmap'
        );
    }
    
    /**
     * Get category colors for markers
     */
    public function get_category_colors() {
        return array(
            'restaurant' => '#e74c3c',
            'cafe' => '#f39c12',
            'lodging' => '#3498db',
            'park' => '#27ae60',
            'museum' => '#9b59b6',
            'library' => '#34495e',
            'pharmacy' => '#e67e22',
            'atm' => '#95a5a6',
            'bank' => '#16a085',
            'gas_station' => '#f1c40f',
            'store' => '#1abc9c',
            'tourist_attraction' => '#e91e63',
            'default' => '#7f8c8d'
        );
    }
    
    /**
     * AJAX handler for getting POIs
     */
    public static function ajax_get_pois() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $filters = array();
        if (isset($_POST['filters'])) {
            $filters = array_map('sanitize_text_field', $_POST['filters']);
        }
        
        $instance = new self();
        $pois = $instance->get_pois_for_map($filters);
        
        wp_send_json_success($pois);
    }
    
    /**
     * AJAX handler for getting POI details
     */
    public static function ajax_get_poi_details() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_id = intval($_POST['poi_id']);
        
        $poi_db = new TNPOI_POI_DB();
        $poi = $poi_db->get_poi($poi_id);
        
        if (!$poi) {
            wp_send_json_error('POI not found');
        }
        
        $poi_data = array(
            'id' => $poi->id,
            'name' => $poi->name,
            'category' => $poi->category ?: 'Uncategorized',
            'trail_name' => $poi->trail_name ?: 'Unknown Trail',
            'address' => $poi->address,
            'latitude' => floatval($poi->latitude),
            'longitude' => floatval($poi->longitude),
            'status' => $poi->status,
            'description' => $poi->description,
            'place_id' => $poi->place_id,
            'created_at' => $poi->created_at,
            'updated_at' => $poi->updated_at
        );
        
        wp_send_json_success($poi_data);
    }
    
    /**
     * Get tile provider URL
     */
    public function get_tile_provider_url($provider) {
        $providers = array(
            'openstreetmap' => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'cartodb' => 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
            'esri' => 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            'stamen' => 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.png'
        );
        
        return $providers[$provider] ?? $providers['openstreetmap'];
    }
    
    /**
     * Get tile provider attribution
     */
    public function get_tile_provider_attribution($provider) {
        $attributions = array(
            'openstreetmap' => '© OpenStreetMap contributors',
            'cartodb' => '© CartoDB',
            'esri' => '© Esri',
            'stamen' => '© Stamen Design'
        );
        
        return $attributions[$provider] ?? $attributions['openstreetmap'];
    }
    
    /**
     * Get sync preview data (sampled points and search areas)
     */
    public function get_sync_preview_data($trail_id, $search_radius = 500, $coordinate_interval = 200, $use_adaptive_sampling = false) {
        error_log('TNPOI Map Preview: Getting sync preview data for trail_id: ' . $trail_id);
        
        // Get the enhanced trail data that was already fetched
        $trail_config = get_option('trail_navigator_config', array());
        $trails = isset($trail_config['trails']) ? $trail_config['trails'] : array();
        
        $selected_trail = null;
        foreach ($trails as $trail) {
            if ((string)$trail['routeId'] === (string)$trail_id) {
                $selected_trail = $trail;
                break;
            }
        }
        
        // If no trail found or no track points, try to fetch them
        if (!$selected_trail || empty($selected_trail['trackPoints'])) {
            error_log('TNPOI Map Preview: No trail data found, fetching coordinates for trail_id: ' . $trail_id);
            $selected_trail = $this->get_complete_trail_data(array('routeId' => $trail_id));
        }
        
        if (!$selected_trail || empty($selected_trail['trackPoints'])) {
            error_log('TNPOI Map Preview: Failed to get trail data with coordinates for trail_id: ' . $trail_id);
            return array(
                'trail_id' => $trail_id,
                'search_radius' => $search_radius,
                'coordinate_interval' => $coordinate_interval,
                'sampled_points' => array(),
                'total_points' => 0,
                'estimated_api_calls' => 0
            );
        }
        
        error_log('TNPOI Map Preview: Found trail with ' . count($selected_trail['trackPoints']) . ' track points');
        
        // Use the adaptive sampling parameter passed to the method
        error_log('TNPOI Map Preview: Adaptive sampling enabled: ' . ($use_adaptive_sampling ? 'true' : 'false'));
        
        if ($use_adaptive_sampling) {
            error_log('TNPOI Map Preview: Using adaptive sampling based on POI density');
            $sampled_points = $this->sample_track_points_adaptive($selected_trail['trackPoints'], $coordinate_interval, $search_radius);
        } else {
            error_log('TNPOI Map Preview: Using uniform sampling');
            $sampled_points = $this->sample_track_points($selected_trail['trackPoints'], $coordinate_interval);
        }
        
        $preview_data = array(
            'trail_id' => $trail_id,
            'search_radius' => $search_radius,
            'coordinate_interval' => $coordinate_interval,
            'sampled_points' => array(),
            'total_points' => count($sampled_points),
            'estimated_api_calls' => count($sampled_points),
            'adaptive_sampling' => $use_adaptive_sampling
        );
        
        foreach ($sampled_points as $point) {
            $preview_data['sampled_points'][] = array(
                'lat' => floatval($point['lat']),
                'lng' => floatval($point['lng']),
                'search_radius' => $point['search_radius'] ?? $search_radius,
                'density_score' => $point['density_score'] ?? 0
            );
        }
        
        error_log('TNPOI Map Preview: Generated sync preview with ' . count($sampled_points) . ' sampled points, interval: ' . $coordinate_interval . 'm, radius: ' . $search_radius . 'm');
        
        return $preview_data;
    }
    
    /**
     * Sample track points with specified distance interval
     */
    private function sample_track_points($track_points, $interval) {
        if (empty($track_points) || count($track_points) < 2) {
            return array();
        }
        
        $sampled_points = array();
        $last_sampled_point = null;
        $cumulative_distance = 0;
        
        // Always add the first point
        $sampled_points[] = $track_points[0];
        $last_sampled_point = $track_points[0];
        error_log('TNPOI Map Preview: Added first point at index 0');
        
        // Calculate cumulative distance and sample at intervals
        for ($i = 1; $i < count($track_points); $i++) {
            $current_point = $track_points[$i];
            $segment_distance = $this->calculate_distance(
                $last_sampled_point['lat'], $last_sampled_point['lng'],
                $current_point['lat'], $current_point['lng']
            );
            
            $cumulative_distance += $segment_distance;
            
            if ($cumulative_distance >= $interval) {
                $sampled_points[] = $current_point;
                $last_sampled_point = $current_point;
                $cumulative_distance = 0; // Reset for next interval
                error_log('TNPOI Map Preview: Added point at index ' . $i . ' (cumulative distance: ' . round($cumulative_distance + $segment_distance) . 'm)');
            }
        }
        
        error_log('TNPOI Map Preview: Distance-based sampling complete. Sampled ' . count($sampled_points) . ' points from ' . count($track_points) . ' total points');
        return $sampled_points;
    }
    
    /**
     * Sample track points with adaptive distance intervals based on POI density
     */
    private function sample_track_points_adaptive($track_points, $base_interval, $base_radius) {
        if (empty($track_points) || count($track_points) < 2) {
            return array();
        }
        
        $sampled_points = array();
        $last_sampled_point = null;
        $cumulative_distance = 0;
        
        // Always add the first point with estimated density
        $density_score = $this->estimate_density_from_location($track_points[0]['lat'], $track_points[0]['lng']);
        $adaptive_radius = $this->get_adaptive_radius($density_score, $base_radius);
        
        $sampled_points[] = array(
            'lat' => $track_points[0]['lat'],
            'lng' => $track_points[0]['lng'],
            'search_radius' => $adaptive_radius,
            'density_score' => $density_score
        );
        $last_sampled_point = $track_points[0];
        error_log('TNPOI Map Preview: Added first point at index 0 (estimated density: ' . round($density_score, 2) . ', radius: ' . $adaptive_radius . 'm)');
        
        // Calculate cumulative distance and sample at adaptive intervals
        for ($i = 1; $i < count($track_points); $i++) {
            $current_point = $track_points[$i];
            $segment_distance = $this->calculate_distance(
                $last_sampled_point['lat'], $last_sampled_point['lng'],
                $current_point['lat'], $current_point['lng']
            );
            
            $cumulative_distance += $segment_distance;
            
            // Estimate density and get adaptive interval for current location
            $density_score = $this->estimate_density_from_location($current_point['lat'], $current_point['lng']);
            $adaptive_interval = $this->get_adaptive_interval($density_score, $base_interval);
            
            if ($cumulative_distance >= $adaptive_interval) {
                $adaptive_radius = $this->get_adaptive_radius($density_score, $base_radius);
                
                $sampled_points[] = array(
                    'lat' => $current_point['lat'],
                    'lng' => $current_point['lng'],
                    'search_radius' => $adaptive_radius,
                    'density_score' => $density_score
                );
                $last_sampled_point = $current_point;
                $cumulative_distance = 0; // Reset for next interval
                error_log('TNPOI Map Preview: Added point at index ' . $i . ' (cumulative distance: ' . round($cumulative_distance + $segment_distance) . 'm, estimated density: ' . round($density_score, 2) . ', radius: ' . $adaptive_radius . 'm)');
            }
        }
        
        error_log('TNPOI Map Preview: Adaptive distance-based sampling complete. Sampled ' . count($sampled_points) . ' points from ' . count($track_points) . ' total points');
        return $sampled_points;
    }
    
    /**
     * Analyze area density around a point using OSM data
     */
    private function analyze_area_density($lat, $lng) {
        error_log('TNPOI Map Preview: Analyzing density for coordinates: ' . $lat . ', ' . $lng);
        
        // Query OSM Overpass API for area characteristics
        $osm_data = $this->query_osm_area_data($lat, $lng);
        
        // Calculate density score from OSM data
        $density_score = $this->calculate_area_density($osm_data);
        
        error_log('TNPOI Map Preview: Density score calculated: ' . $density_score);
        
        return $density_score;
    }
    
    /**
     * Get adaptive interval based on density score
     */
    private function get_adaptive_interval($density_score, $base_interval) {
        // High density areas: sample more frequently (smaller intervals)
        // Low density areas: sample less frequently (larger intervals)
        if ($density_score > 0.7) {
            return $base_interval * 0.5; // High density: 50% of base interval
        } elseif ($density_score > 0.4) {
            return $base_interval * 0.75; // Medium density: 75% of base interval
        } elseif ($density_score > 0.2) {
            return $base_interval; // Normal density: base interval
        } else {
            return $base_interval * 1.5; // Low density: 150% of base interval
        }
    }
    
    /**
     * Get adaptive radius based on density score
     */
    private function get_adaptive_radius($density_score, $base_radius) {
        // High density areas: smaller search radius (more focused)
        // Low density areas: larger search radius (broader search)
        if ($density_score > 0.7) {
            return intval($base_radius * 0.6); // High density: 60% of base radius
        } elseif ($density_score > 0.4) {
            return intval($base_radius * 0.8); // Medium density: 80% of base radius
        } elseif ($density_score > 0.2) {
            return $base_radius; // Normal density: base radius
        } else {
            return intval($base_radius * 1.3); // Low density: 130% of base radius
        }
    }
    
    /**
     * Query OSM Overpass API for pedestrian-friendly POI data
     */
    private function query_osm_area_data($lat, $lng) {
        $radius = 500; // 500m radius to analyze
        
        // Overpass query specifically for pedestrian-friendly POIs
        $query = "
            [out:json][timeout:15];
            (
                // Retail and food establishments
                node[\"shop\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"restaurant\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"cafe\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"bar\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"fast_food\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"ice_cream\"](around:$radius,$lat,$lng);
                
                // Parks and recreation
                node[\"leisure\"=\"park\"](around:$radius,$lat,$lng);
                node[\"leisure\"=\"playground\"](around:$radius,$lat,$lng);
                node[\"leisure\"=\"garden\"](around:$radius,$lat,$lng);
                node[\"leisure\"=\"fitness_centre\"](around:$radius,$lat,$lng);
                
                // Landmarks and tourist attractions
                node[\"tourism\"=\"attraction\"](around:$radius,$lat,$lng);
                node[\"historic\"](around:$radius,$lat,$lng);
                node[\"tourism\"=\"museum\"](around:$radius,$lat,$lng);
                node[\"tourism\"=\"viewpoint\"](around:$radius,$lat,$lng);
                
                // Pedestrian amenities
                node[\"amenity\"=\"toilets\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"drinking_water\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"bench\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"shelter\"](around:$radius,$lat,$lng);
                
                // Entertainment and culture
                node[\"amenity\"=\"cinema\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"theatre\"](around:$radius,$lat,$lng);
                node[\"amenity\"=\"arts_centre\"](around:$radius,$lat,$lng);
                
                // Educational (visitor centers, etc.)
                node[\"amenity\"=\"school\"](around:$radius,$lat,$lng);
                node[\"tourism\"=\"information\"](around:$radius,$lat,$lng);
            );
            out body;
            >;
            out skel qt;
        ";
        
        $url = 'https://overpass-api.de/api/interpreter';
        $response = wp_remote_post($url, array(
            'body' => $query,
            'timeout' => 20,
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            )
        ));
        
        if (is_wp_error($response)) {
            error_log('TNPOI Map Preview: OSM query error: ' . $response->get_error_message());
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        return json_decode($body, true);
    }
    
    /**
     * Calculate pedestrian-friendly POI density score from OSM data
     */
    private function calculate_area_density($osm_data) {
        if (empty($osm_data['elements'])) {
            return 0.1; // Default to low density if no data
        }
        
        $retail_count = 0;
        $food_count = 0;
        $park_count = 0;
        $landmark_count = 0;
        $amenity_count = 0;
        $entertainment_count = 0;
        
        foreach ($osm_data['elements'] as $element) {
            if (isset($element['tags'])) {
                $tags = $element['tags'];
                
                // Retail establishments
                if (isset($tags['shop'])) {
                    $retail_count++;
                }
                
                // Food establishments
                if (isset($tags['amenity']) && in_array($tags['amenity'], ['restaurant', 'cafe', 'bar', 'fast_food', 'ice_cream'])) {
                    $food_count++;
                }
                
                // Parks and recreation
                if (isset($tags['leisure']) && in_array($tags['leisure'], ['park', 'playground', 'garden', 'fitness_centre'])) {
                    $park_count++;
                }
                
                // Landmarks and tourist attractions
                if (isset($tags['tourism']) && in_array($tags['tourism'], ['attraction', 'museum', 'viewpoint']) || isset($tags['historic'])) {
                    $landmark_count++;
                }
                
                // Pedestrian amenities
                if (isset($tags['amenity']) && in_array($tags['amenity'], ['toilets', 'drinking_water', 'bench', 'shelter'])) {
                    $amenity_count++;
                }
                
                // Entertainment and culture
                if (isset($tags['amenity']) && in_array($tags['amenity'], ['cinema', 'theatre', 'arts_centre'])) {
                    $entertainment_count++;
                }
            }
        }
        
        // Calculate weighted density score (0-1)
        $total_pois = $retail_count + $food_count + $park_count + $landmark_count + $amenity_count + $entertainment_count;
        
        if ($total_pois === 0) {
            return 0.1;
        }
        
        // Weighted scoring based on importance for trail users
        $retail_score = min($retail_count / 8, 1.0) * 0.25; // 25% weight - shops
        $food_score = min($food_count / 6, 1.0) * 0.30; // 30% weight - restaurants/cafes
        $park_score = min($park_count / 3, 1.0) * 0.20; // 20% weight - parks/recreation
        $landmark_score = min($landmark_count / 2, 1.0) * 0.15; // 15% weight - landmarks
        $amenity_score = min($amenity_count / 4, 1.0) * 0.08; // 8% weight - amenities
        $entertainment_score = min($entertainment_count / 2, 1.0) * 0.02; // 2% weight - entertainment
        
        $density_score = $retail_score + $food_score + $park_score + $landmark_score + $amenity_score + $entertainment_score;
        
        error_log('TNPOI Map Preview: POI counts - Retail: ' . $retail_count . ', Food: ' . $food_count . ', Parks: ' . $park_count . ', Landmarks: ' . $landmark_count . ', Amenities: ' . $amenity_count . ', Entertainment: ' . $entertainment_count . ', Total: ' . $total_pois . ', Score: ' . round($density_score, 3));
        
        return $density_score;
    }
    
    /**
     * Estimate pedestrian-friendly POI density from location
     * Focuses on retail, landmarks, parks, and pedestrian amenities
     */
    private function estimate_density_from_location($lat, $lng) {
        // Known pedestrian-friendly commercial areas along the Swamp Rabbit Trail
        $pedestrian_friendly_areas = array(
            // Downtown Greenville - High density retail, restaurants, landmarks
            array('lat' => 34.8508, 'lng' => -82.3839, 'radius' => 1500, 'density' => 0.9),
            
            // Falls Park area - Landmarks, restaurants, tourist attractions
            array('lat' => 34.8475, 'lng' => -82.3989, 'radius' => 1200, 'density' => 0.85),
            
            // Conestee Nature Preserve - Park, visitor center, amenities
            array('lat' => 34.7699, 'lng' => -82.3493, 'radius' => 1000, 'density' => 0.7),
            
            // Travelers Rest - Restaurants, shops, trail amenities
            array('lat' => 34.9916, 'lng' => -82.4640, 'radius' => 1200, 'density' => 0.75),
            
            // Swamp Rabbit Cafe & Grocery area - Food, retail
            array('lat' => 34.8136, 'lng' => -82.3276, 'radius' => 800, 'density' => 0.6),
            
            // Cleveland Park - Park, playground, amenities
            array('lat' => 34.8454, 'lng' => -82.4640, 'radius' => 1000, 'density' => 0.65),
            
            // Greenville Tech area - Campus amenities, nearby retail
            array('lat' => 34.8350, 'lng' => -82.3650, 'radius' => 1000, 'density' => 0.55),
            
            // Mauldin area - Some retail, restaurants
            array('lat' => 34.7800, 'lng' => -82.3100, 'radius' => 1200, 'density' => 0.5),
        );
        
        // Check if point is in a known pedestrian-friendly area
        foreach ($pedestrian_friendly_areas as $area) {
            $distance = $this->calculate_distance($lat, $lng, $area['lat'], $area['lng']);
            if ($distance <= $area['radius']) {
                // Add some variation based on distance from center
                $distance_factor = 1 - ($distance / $area['radius']);
                $variation = (rand(-10, 10) / 100); // ±0.1 variation
                return max(0.1, min(1.0, $area['density'] * $distance_factor + $variation));
            }
        }
        
        // Check for proximity to trail corridor (medium density)
        $trail_corridor_areas = array(
            array('lat' => 34.8200, 'lng' => -82.3500, 'radius' => 500), // Central trail corridor
            array('lat' => 34.8600, 'lng' => -82.4200, 'radius' => 500), // Northern corridor
            array('lat' => 34.7600, 'lng' => -82.3300, 'radius' => 500), // Southern corridor
        );
        
        foreach ($trail_corridor_areas as $area) {
            $distance = $this->calculate_distance($lat, $lng, $area['lat'], $area['lng']);
            if ($distance <= $area['radius']) {
                return 0.3 + (rand(0, 20) / 100); // 0.3-0.5 for trail corridor
            }
        }
        
        // Default to low density for rural/remote areas
        return 0.1 + (rand(0, 15) / 100); // 0.1-0.25 for rural areas
    }
    
    /**
     * Calculate distance between two points in meters
     */
    private function calculate_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // meters
        
        $lat1_rad = deg2rad($lat1);
        $lng1_rad = deg2rad($lng1);
        $lat2_rad = deg2rad($lat2);
        $lng2_rad = deg2rad($lng2);
        
        $dlat = $lat2_rad - $lat1_rad;
        $dlng = $lng2_rad - $lng1_rad;
        
        $a = sin($dlat / 2) * sin($dlat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($dlng / 2) * sin($dlng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * AJAX handler for getting sync preview data
     */
    public static function ajax_get_sync_preview() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $trail_id = sanitize_text_field($_POST['trail_id'] ?? '');
        $search_radius = intval($_POST['search_radius'] ?? 500);
        $coordinate_interval = intval($_POST['coordinate_interval'] ?? 200);
        $enable_adaptive = isset($_POST['enable_adaptive']) ? (bool)$_POST['enable_adaptive'] : false;
        
        // Debug the received parameters
        error_log('TNPOI Map Preview: AJAX received trail_id: ' . $trail_id);
        error_log('TNPOI Map Preview: AJAX received search_radius: ' . $search_radius);
        error_log('TNPOI Map Preview: AJAX received coordinate_interval: ' . $coordinate_interval);
        error_log('TNPOI Map Preview: AJAX received enable_adaptive raw: ' . ($_POST['enable_adaptive'] ?? 'NOT_SET'));
        error_log('TNPOI Map Preview: AJAX received enable_adaptive processed: ' . ($enable_adaptive ? 'true' : 'false'));
        
        if (empty($trail_id)) {
            wp_send_json_error('Trail ID is required');
        }
        
        $instance = new self();
        $preview_data = $instance->get_sync_preview_data($trail_id, $search_radius, $coordinate_interval, $enable_adaptive);
        
        wp_send_json_success($preview_data);
    }
    
    /**
     * Fetch trail coordinates from RideWithGPS if not available
     */
    public function fetch_trail_coordinates($route_id) {
        // Try multiple API key option names for compatibility
        $api_key = get_option('tnpoi_ridewithgps_api_key', '');
        if (empty($api_key)) {
            $api_key = get_option('tcgp2_ridewithgps_api_key', '');
        }
        if (empty($api_key)) {
            $api_key = get_option('tcgp_ridewithgps_api_key', '');
        }
        
        if (empty($api_key)) {
            error_log('TNPOI Map Preview: No RideWithGPS API key configured');
            return array();
        }
        
        $url = "https://ridewithgps.com/routes/{$route_id}.json?apikey={$api_key}";
        error_log('TNPOI Map Preview: Fetching RideWithGPS JSON from: ' . $url);
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array('User-Agent' => 'TrailNavigator/3.0')
        ));
        
        if (is_wp_error($response)) {
            error_log('TNPOI Map Preview: Error fetching trail coordinates: ' . $response->get_error_message());
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        error_log('TNPOI Map Preview: RideWithGPS JSON response (first 500 chars): ' . substr($body, 0, 500));
        
        $data = json_decode($body, true);
        
        // Check for the correct data structure (route.track_points)
        if (!$data || !isset($data['route']['track_points'])) {
            error_log('TNPOI Map Preview: No track_points found in RideWithGPS JSON for routeId ' . $route_id);
            return array();
        }
        
        $track_points = $data['route']['track_points'];
        error_log('TNPOI Map Preview: Fetched ' . count($track_points) . ' track points from RideWithGPS');
        
        // Convert to the expected format
        $coordinates = array();
        foreach ($track_points as $point) {
            $coordinates[] = array(
                'lat' => $point['y'],
                'lng' => $point['x']
            );
        }
        
        error_log('TNPOI Map Preview: Parsed ' . count($coordinates) . ' coordinates from RideWithGPS JSON for routeId ' . $route_id);
        return $coordinates;
    }
    
    /**
     * Get complete trail data with coordinates
     */
    public function get_complete_trail_data($trail) {
        if (isset($trail['trackPoints']) && !empty($trail['trackPoints'])) {
            return $trail;
        }
        
        // Try to fetch coordinates from RideWithGPS
        if (isset($trail['routeId'])) {
            $coordinates = $this->fetch_trail_coordinates($trail['routeId']);
            if (!empty($coordinates)) {
                $trail['trackPoints'] = $coordinates;
                error_log('TNPOI Map Preview: Added ' . count($coordinates) . ' track points to trail ' . $trail['routeId']);
                return $trail;
            } else {
                error_log('TNPOI Map Preview: Failed to fetch coordinates for trail ' . $trail['routeId']);
            }
        } else {
            error_log('TNPOI Map Preview: No routeId found in trail data');
        }
        
        return $trail;
    }
}

// Initialize the class
new TNPOI_Map_Preview();

// Register AJAX handlers
add_action('wp_ajax_tnpoi_get_pois', array('TNPOI_Map_Preview', 'ajax_get_pois'));
add_action('wp_ajax_tnpoi_get_poi_details', array('TNPOI_Map_Preview', 'ajax_get_poi_details'));
add_action('wp_ajax_tnpoi_get_sync_preview', array('TNPOI_Map_Preview', 'ajax_get_sync_preview'));
