<?php
/**
 * Map Preview Class
 * 
 * Handles map functionality and POI visualization using Leaflet.js
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class TNPOI_Map_Preview {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Enqueue map scripts and styles
     */
    public function enqueue_scripts() {
        // Only enqueue on our plugin pages
        if (!$this->is_plugin_page()) {
            return;
        }
        
        // Enqueue Leaflet.js
        wp_enqueue_script(
            'leaflet-js',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
            array(),
            '1.9.4',
            true
        );
        
        wp_enqueue_style(
            'leaflet-css',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
            array(),
            '1.9.4'
        );
        
        // Enqueue our custom map script
        wp_enqueue_script(
            'tnpoi-map',
            TNPOI_PLUGIN_URL . 'assets/js/map.js',
            array('leaflet-js', 'jquery'),
            TNPOI_VERSION,
            true
        );
        
        // Localize script with AJAX URL and nonce
        wp_localize_script('tnpoi-map', 'tnpoi_map_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tnpoi_map_nonce'),
            'plugin_url' => TNPOI_PLUGIN_URL
        ));
    }
    
    /**
     * Check if current page is a plugin page
     */
    private function is_plugin_page() {
        $screen = get_current_screen();
        if (!$screen) {
            return false;
        }
        
        // Debug: Log the current screen ID
        error_log('TNPOI Map Preview: Current screen ID: ' . $screen->id);
        
        $plugin_pages = array(
            'toplevel_page_tnpoi-dashboard',
            'trail-navigator_page_tnpoi-poi-manager',
            'trail-navigator_page_tnpoi-sync',
            'trail-navigator_page_tnpoi-map-preview',
            'trail-navigator_page_tnpoi-settings',
            // Add more generic patterns
            'tnpoi',
            'trail-navigator'
        );
        
        $is_plugin_page = false;
        foreach ($plugin_pages as $page) {
            if (strpos($screen->id, $page) !== false) {
                $is_plugin_page = true;
                break;
            }
        }
        
        error_log('TNPOI Map Preview: Is plugin page: ' . ($is_plugin_page ? 'true' : 'false'));
        return $is_plugin_page;
    }
    
    /**
     * Get POIs for map display
     */
    public function get_pois_for_map($filters = array()) {
        $poi_db = new TNPOI_POI_DB();
        
        $search = isset($filters['search']) ? sanitize_text_field($filters['search']) : '';
        $category = isset($filters['category']) ? sanitize_text_field($filters['category']) : '';
        $trail = isset($filters['trail']) ? sanitize_text_field($filters['trail']) : '';
        $status = isset($filters['status']) ? sanitize_text_field($filters['status']) : '';
        
        $pois = $poi_db->get_pois(1, 1000, $search, $category, $trail, $status);
        
        $map_pois = array();
        foreach ($pois as $poi) {
            $map_pois[] = array(
                'id' => $poi->id,
                'name' => $poi->name,
                'category' => $poi->category ?: 'Uncategorized',
                'trail_name' => $poi->trail_name ?: 'Unknown Trail',
                'address' => $poi->address,
                'latitude' => floatval($poi->latitude),
                'longitude' => floatval($poi->longitude),
                'status' => $poi->status,
                'description' => $poi->description,
                'place_id' => $poi->place_id
            );
        }
        
        return $map_pois;
    }
    
    /**
     * Get map configuration
     */
    public function get_map_config() {
        $settings = get_option('tnpoi_settings', array());
        
        return array(
            'center_lat' => $settings['default_map_center_lat'] ?? 39.8283,
            'center_lng' => $settings['default_map_center_lng'] ?? -98.5795,
            'zoom' => $settings['default_map_zoom'] ?? 4,
            'tile_provider' => $settings['map_tile_provider'] ?? 'openstreetmap'
        );
    }
    
    /**
     * Get category colors for markers
     */
    public function get_category_colors() {
        return array(
            'restaurant' => '#e74c3c',
            'cafe' => '#f39c12',
            'lodging' => '#3498db',
            'park' => '#27ae60',
            'museum' => '#9b59b6',
            'library' => '#34495e',
            'pharmacy' => '#e67e22',
            'atm' => '#95a5a6',
            'bank' => '#16a085',
            'gas_station' => '#f1c40f',
            'store' => '#1abc9c',
            'tourist_attraction' => '#e91e63',
            'default' => '#7f8c8d'
        );
    }
    
    /**
     * AJAX handler for getting POIs
     */
    public static function ajax_get_pois() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $filters = array();
        if (isset($_POST['filters'])) {
            $filters = array_map('sanitize_text_field', $_POST['filters']);
        }
        
        $instance = new self();
        $pois = $instance->get_pois_for_map($filters);
        
        wp_send_json_success($pois);
    }
    
    /**
     * AJAX handler for getting POI details
     */
    public static function ajax_get_poi_details() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $poi_id = intval($_POST['poi_id']);
        
        $poi_db = new TNPOI_POI_DB();
        $poi = $poi_db->get_poi($poi_id);
        
        if (!$poi) {
            wp_send_json_error('POI not found');
        }
        
        $poi_data = array(
            'id' => $poi->id,
            'name' => $poi->name,
            'category' => $poi->category ?: 'Uncategorized',
            'trail_name' => $poi->trail_name ?: 'Unknown Trail',
            'address' => $poi->address,
            'latitude' => floatval($poi->latitude),
            'longitude' => floatval($poi->longitude),
            'status' => $poi->status,
            'description' => $poi->description,
            'place_id' => $poi->place_id,
            'created_at' => $poi->created_at,
            'updated_at' => $poi->updated_at
        );
        
        wp_send_json_success($poi_data);
    }
    
    /**
     * Get tile provider URL
     */
    public function get_tile_provider_url($provider) {
        $providers = array(
            'openstreetmap' => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'cartodb' => 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
            'esri' => 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            'stamen' => 'https://stamen-tiles-{s}.a.ssl.fastly.net/terrain/{z}/{x}/{y}{r}.png'
        );
        
        return $providers[$provider] ?? $providers['openstreetmap'];
    }
    
    /**
     * Get tile provider attribution
     */
    public function get_tile_provider_attribution($provider) {
        $attributions = array(
            'openstreetmap' => '© OpenStreetMap contributors',
            'cartodb' => '© CartoDB',
            'esri' => '© Esri',
            'stamen' => '© Stamen Design'
        );
        
        return $attributions[$provider] ?? $attributions['openstreetmap'];
    }
    
    /**
     * Get sync preview data (sampled points and search areas)
     */
    public function get_sync_preview_data($trail_id, $search_radius = 500, $coordinate_interval = 200) {
        error_log('TNPOI Map Preview: Getting sync preview data for trail_id: ' . $trail_id);
        
        // Get the enhanced trail data that was already fetched
        $trail_config = get_option('trail_navigator_config', array());
        $trails = isset($trail_config['trails']) ? $trail_config['trails'] : array();
        
        $selected_trail = null;
        foreach ($trails as $trail) {
            if ((string)$trail['routeId'] === (string)$trail_id) {
                $selected_trail = $trail;
                break;
            }
        }
        
        // If no trail found or no track points, try to fetch them
        if (!$selected_trail || empty($selected_trail['trackPoints'])) {
            error_log('TNPOI Map Preview: No trail data found, fetching coordinates for trail_id: ' . $trail_id);
            $selected_trail = $this->get_complete_trail_data(array('routeId' => $trail_id));
        }
        
        if (!$selected_trail || empty($selected_trail['trackPoints'])) {
            error_log('TNPOI Map Preview: Failed to get trail data with coordinates for trail_id: ' . $trail_id);
            return array(
                'trail_id' => $trail_id,
                'search_radius' => $search_radius,
                'coordinate_interval' => $coordinate_interval,
                'sampled_points' => array(),
                'total_points' => 0,
                'estimated_api_calls' => 0
            );
        }
        
        error_log('TNPOI Map Preview: Found trail with ' . count($selected_trail['trackPoints']) . ' track points');
        
        // Sample the track points directly
        $sampled_points = $this->sample_track_points($selected_trail['trackPoints'], $coordinate_interval);
        
        $preview_data = array(
            'trail_id' => $trail_id,
            'search_radius' => $search_radius,
            'coordinate_interval' => $coordinate_interval,
            'sampled_points' => array(),
            'total_points' => count($sampled_points),
            'estimated_api_calls' => count($sampled_points)
        );
        
        foreach ($sampled_points as $point) {
            $preview_data['sampled_points'][] = array(
                'lat' => floatval($point['lat']),
                'lng' => floatval($point['lng']),
                'search_radius' => $search_radius
            );
        }
        
        error_log('TNPOI Map Preview: Generated sync preview with ' . count($sampled_points) . ' sampled points, interval: ' . $coordinate_interval . 'm, radius: ' . $search_radius . 'm');
        
        return $preview_data;
    }
    
    /**
     * Sample track points with specified interval
     */
    private function sample_track_points($track_points, $interval) {
        if (empty($track_points) || count($track_points) < 2) {
            return array();
        }
        
        $sampled_points = array();
        $last_point = null;
        
        foreach ($track_points as $index => $pt) {
            if (!$last_point) {
                $sampled_points[] = $pt;
                $last_point = $pt;
                error_log('TNPOI Map Preview: Added first point at index ' . $index);
            } else {
                $dist = $this->calculate_distance($last_point['lat'], $last_point['lng'], $pt['lat'], $pt['lng']);
                if ($dist >= $interval) {
                    $sampled_points[] = $pt;
                    $last_point = $pt;
                    error_log('TNPOI Map Preview: Added point at index ' . $index . ' (distance: ' . round($dist) . 'm)');
                }
            }
        }
        
        error_log('TNPOI Map Preview: Sampling complete. Sampled ' . count($sampled_points) . ' points from ' . count($track_points) . ' total points');
        return $sampled_points;
    }
    
    /**
     * Calculate distance between two points in meters
     */
    private function calculate_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // meters
        
        $lat1_rad = deg2rad($lat1);
        $lng1_rad = deg2rad($lng1);
        $lat2_rad = deg2rad($lat2);
        $lng2_rad = deg2rad($lng2);
        
        $dlat = $lat2_rad - $lat1_rad;
        $dlng = $lng2_rad - $lng1_rad;
        
        $a = sin($dlat / 2) * sin($dlat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($dlng / 2) * sin($dlng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * AJAX handler for getting sync preview data
     */
    public static function ajax_get_sync_preview() {
        check_ajax_referer('tnpoi_map_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $trail_id = sanitize_text_field($_POST['trail_id'] ?? '');
        $search_radius = intval($_POST['search_radius'] ?? 500);
        $coordinate_interval = intval($_POST['coordinate_interval'] ?? 200);
        
        if (empty($trail_id)) {
            wp_send_json_error('Trail ID is required');
        }
        
        $instance = new self();
        $preview_data = $instance->get_sync_preview_data($trail_id, $search_radius, $coordinate_interval);
        
        wp_send_json_success($preview_data);
    }
    
    /**
     * Fetch trail coordinates from RideWithGPS if not available
     */
    public function fetch_trail_coordinates($route_id) {
        // Try multiple API key option names for compatibility
        $api_key = get_option('tnpoi_ridewithgps_api_key', '');
        if (empty($api_key)) {
            $api_key = get_option('tcgp2_ridewithgps_api_key', '');
        }
        if (empty($api_key)) {
            $api_key = get_option('tcgp_ridewithgps_api_key', '');
        }
        
        if (empty($api_key)) {
            error_log('TNPOI Map Preview: No RideWithGPS API key configured');
            return array();
        }
        
        $url = "https://ridewithgps.com/routes/{$route_id}.json?apikey={$api_key}";
        error_log('TNPOI Map Preview: Fetching RideWithGPS JSON from: ' . $url);
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array('User-Agent' => 'TrailNavigator/3.0')
        ));
        
        if (is_wp_error($response)) {
            error_log('TNPOI Map Preview: Error fetching trail coordinates: ' . $response->get_error_message());
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        error_log('TNPOI Map Preview: RideWithGPS JSON response (first 500 chars): ' . substr($body, 0, 500));
        
        $data = json_decode($body, true);
        
        // Check for the correct data structure (route.track_points)
        if (!$data || !isset($data['route']['track_points'])) {
            error_log('TNPOI Map Preview: No track_points found in RideWithGPS JSON for routeId ' . $route_id);
            return array();
        }
        
        $track_points = $data['route']['track_points'];
        error_log('TNPOI Map Preview: Fetched ' . count($track_points) . ' track points from RideWithGPS');
        
        // Convert to the expected format
        $coordinates = array();
        foreach ($track_points as $point) {
            $coordinates[] = array(
                'lat' => $point['y'],
                'lng' => $point['x']
            );
        }
        
        error_log('TNPOI Map Preview: Parsed ' . count($coordinates) . ' coordinates from RideWithGPS JSON for routeId ' . $route_id);
        return $coordinates;
    }
    
    /**
     * Get complete trail data with coordinates
     */
    public function get_complete_trail_data($trail) {
        if (isset($trail['trackPoints']) && !empty($trail['trackPoints'])) {
            return $trail;
        }
        
        // Try to fetch coordinates from RideWithGPS
        if (isset($trail['routeId'])) {
            $coordinates = $this->fetch_trail_coordinates($trail['routeId']);
            if (!empty($coordinates)) {
                $trail['trackPoints'] = $coordinates;
                error_log('TNPOI Map Preview: Added ' . count($coordinates) . ' track points to trail ' . $trail['routeId']);
                return $trail;
            } else {
                error_log('TNPOI Map Preview: Failed to fetch coordinates for trail ' . $trail['routeId']);
            }
        } else {
            error_log('TNPOI Map Preview: No routeId found in trail data');
        }
        
        return $trail;
    }
}

// Initialize the class
new TNPOI_Map_Preview();

// Register AJAX handlers
add_action('wp_ajax_tnpoi_get_pois', array('TNPOI_Map_Preview', 'ajax_get_pois'));
add_action('wp_ajax_tnpoi_get_poi_details', array('TNPOI_Map_Preview', 'ajax_get_poi_details'));
add_action('wp_ajax_tnpoi_get_sync_preview', array('TNPOI_Map_Preview', 'ajax_get_sync_preview'));
