<?php
/**
 * POI Sync Class
 * 
 * Handles Google Places API integration and POI synchronization
 * with coordinate thinning and progress tracking
 */

if (!defined('ABSPATH')) {
    exit;
}

class TNPOI_Sync {
    
    private $api_key;
    private $db;
    
    public function __construct() {
        $this->db = new TNPOI_DB();
        $this->api_key = get_option('tnpoi_google_places_api_key', '');
        
        add_action('wp_ajax_tnpoi_sync_pois', array($this, 'ajax_sync_pois'));
        add_action('wp_ajax_tnpoi_get_sync_progress', array($this, 'ajax_get_sync_progress'));
    }
    
    /**
     * AJAX handler for POI synchronization
     */
    public function ajax_sync_pois() {
        check_ajax_referer('tnpoi_sync_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $action = sanitize_text_field($_POST['action_type'] ?? '');
        
        switch ($action) {
            case 'start':
                $this->start_sync();
                break;
            case 'stop':
                $this->stop_sync();
                break;
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    /**
     * AJAX handler for sync progress
     */
    public function ajax_get_sync_progress() {
        check_ajax_referer('tnpoi_sync_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $progress = get_transient('tnpoi_sync_progress');
        if (!$progress) {
            $progress = array(
                'status' => 'idle',
                'current' => 0,
                'total' => 0,
                'message' => 'No sync in progress'
            );
        }
        
        wp_send_json_success($progress);
    }
    
    /**
     * Start POI synchronization
     */
    private function start_sync() {
        if (empty($this->api_key)) {
            wp_send_json_error('Google Places API key not configured');
        }
        
        $search_terms = get_option('tnpoi_search_terms', array());
        if (empty($search_terms)) {
            wp_send_json_error('No search terms configured');
        }
        
        // Initialize progress
        $total_terms = count($search_terms);
        $progress = array(
            'status' => 'running',
            'current' => 0,
            'total' => $total_terms,
            'message' => 'Starting sync...'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Start background process
        wp_schedule_single_event(time(), 'tnpoi_process_sync', array($search_terms, 0));
        
        wp_send_json_success(array(
            'message' => 'Sync started',
            'total_terms' => $total_terms
        ));
    }
    
    /**
     * Stop POI synchronization
     */
    private function stop_sync() {
        $progress = array(
            'status' => 'stopped',
            'current' => 0,
            'total' => 0,
            'message' => 'Sync stopped by user'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        wp_clear_scheduled_hook('tnpoi_process_sync');
        
        wp_send_json_success('Sync stopped');
    }
    
    /**
     * Process sync in background
     */
    public function process_sync($search_terms, $current_index = 0) {
        if ($current_index >= count($search_terms)) {
            $this->complete_sync();
            return;
        }
        
        $term = $search_terms[$current_index];
        $this->sync_search_term($term);
        
        // Update progress
        $progress = array(
            'status' => 'running',
            'current' => $current_index + 1,
            'total' => count($search_terms),
            'message' => "Processed: {$term['name']}"
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Schedule next batch
        wp_schedule_single_event(time() + 2, 'tnpoi_process_sync', array($search_terms, $current_index + 1));
    }
    
    /**
     * Sync a single search term
     */
    private function sync_search_term($term) {
        $location = $term['location'];
        $radius = intval($term['radius']);
        $types = $term['types'];
        
        // Search for places
        $places = $this->search_places($location, $radius, $types);
        
        if (empty($places)) {
            return;
        }
        
        // Apply coordinate thinning
        $thinned_places = $this->thin_coordinates($places, $term['min_distance'] ?? 100);
        
        // Save POIs
        foreach ($thinned_places as $place) {
            $this->save_poi($place, $term);
        }
    }
    
    /**
     * Search Google Places API
     */
    private function search_places($location, $radius, $types) {
        $places = array();
        $next_page_token = null;
        
        do {
            $url = add_query_arg(array(
                'location' => $location,
                'radius' => $radius,
                'type' => $types,
                'key' => $this->api_key
            ), 'https://maps.googleapis.com/maps/api/place/nearbysearch/json');
            
            if ($next_page_token) {
                $url = add_query_arg('pagetoken', $next_page_token, $url);
            }
            
            $response = wp_remote_get($url);
            
            if (is_wp_error($response)) {
                error_log('Google Places API error: ' . $response->get_error_message());
                break;
            }
            
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (!$data || $data['status'] !== 'OK') {
                error_log('Google Places API error: ' . ($data['status'] ?? 'Unknown error'));
                break;
            }
            
            $places = array_merge($places, $data['results']);
            $next_page_token = $data['next_page_token'] ?? null;
            
            // Respect API rate limits
            if ($next_page_token) {
                sleep(2);
            }
            
        } while ($next_page_token);
        
        return $places;
    }
    
    /**
     * Apply coordinate thinning to reduce density
     */
    private function thin_coordinates($places, $min_distance) {
        if (empty($places)) {
            return array();
        }
        
        $thinned = array();
        $thinned[] = $places[0]; // Keep first place
        
        foreach ($places as $place) {
            $keep = true;
            
            foreach ($thinned as $kept_place) {
                $distance = $this->calculate_distance(
                    $place['geometry']['location']['lat'],
                    $place['geometry']['location']['lng'],
                    $kept_place['geometry']['location']['lat'],
                    $kept_place['geometry']['location']['lng']
                );
                
                if ($distance < $min_distance) {
                    $keep = false;
                    break;
                }
            }
            
            if ($keep) {
                $thinned[] = $place;
            }
        }
        
        return $thinned;
    }
    
    /**
     * Calculate distance between two coordinates (Haversine formula)
     */
    private function calculate_distance($lat1, $lng1, $lat2, $lng2) {
        $earth_radius = 6371000; // meters
        
        $lat1_rad = deg2rad($lat1);
        $lng1_rad = deg2rad($lng1);
        $lat2_rad = deg2rad($lat2);
        $lng2_rad = deg2rad($lng2);
        
        $dlat = $lat2_rad - $lat1_rad;
        $dlng = $lng2_rad - $lng1_rad;
        
        $a = sin($dlat / 2) * sin($dlat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($dlng / 2) * sin($dlng / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
    
    /**
     * Save POI to database
     */
    private function save_poi($place, $term) {
        $poi_data = array(
            'place_id' => $place['place_id'],
            'name' => $place['name'],
            'address' => $place['vicinity'] ?? '',
            'latitude' => $place['geometry']['location']['lat'],
            'longitude' => $place['geometry']['location']['lng'],
            'types' => implode(',', $place['types']),
            'rating' => $place['rating'] ?? 0,
            'user_ratings_total' => $place['user_ratings_total'] ?? 0,
            'price_level' => $place['price_level'] ?? 0,
            'search_term' => $term['name'],
            'search_location' => $term['location'],
            'search_radius' => $term['radius'],
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        );
        
        $this->db->insert_or_update_poi($poi_data);
    }
    
    /**
     * Complete sync process
     */
    private function complete_sync() {
        $progress = array(
            'status' => 'completed',
            'current' => 0,
            'total' => 0,
            'message' => 'Sync completed successfully'
        );
        set_transient('tnpoi_sync_progress', $progress, HOUR_IN_SECONDS);
        
        // Clear scheduled events
        wp_clear_scheduled_hook('tnpoi_process_sync');
    }
    
    /**
     * Get sync statistics
     */
    public function get_sync_stats() {
        global $wpdb;
        
        $table_name = $this->db->get_table_name();
        
        $stats = array(
            'total_pois' => $wpdb->get_var("SELECT COUNT(*) FROM $table_name"),
            'recent_pois' => $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE created_at >= %s",
                date('Y-m-d H:i:s', strtotime('-24 hours'))
            )),
            'search_terms' => $wpdb->get_var("SELECT COUNT(DISTINCT search_term) FROM $table_name"),
            'last_sync' => get_option('tnpoi_last_sync', 'Never')
        );
        
        return $stats;
    }
}

// Hook for background processing
add_action('tnpoi_process_sync', array('TNPOI_Sync', 'process_sync'), 10, 2); 